package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val api: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(GeminiApiService::class.java)
    }

    suspend fun generateSalesReply(
        customerMessage: String,
        productCatalogContext: String,
        customPrompt: String,
        apiKeyOverride: String = ""
    ): String {
        val apiKey = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই উত্তর দিবে।"
        }

        val systemPromptText = """
            You are a polite, professional, and friendly Digital Sales Bot assistant for an e-commerce store in Bangladesh.
            Respond concisely in Bengali or English (matching the user's language).
            
            Product Catalog Information:
            $productCatalogContext
            
            Bot Instructions:
            $customPrompt
            
            Give direct, helpful answers regarding product prices, specs, and ordering procedures. Keep replies short for chat messaging (under 3 sentences).
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = customerMessage)))),
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPromptText)))
        )

        return try {
            val response = api.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "ধন্যবাদ আপনার আগ্রহের জন্য! অনুগ্রহ করে আপনার অর্ডার বিবরণ জানান।"
        } catch (e: Exception) {
            "ধন্যবাদ আপনার বার্তার জন্য! আমাদের সেলস টিম দ্রুত যোগাযোগ করবে।"
        }
    }
}
