package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerOrderDao {
    @Query("SELECT * FROM customer_orders ORDER BY orderDate DESC")
    fun getAllOrders(): Flow<List<CustomerOrder>>

    @Query("SELECT * FROM customer_orders WHERE status = :status ORDER BY orderDate DESC")
    fun getOrdersByStatus(status: String): Flow<List<CustomerOrder>>

    @Query("SELECT COUNT(*) FROM customer_orders WHERE status = 'PENDING'")
    fun getPendingOrdersCount(): Flow<Int>

    @Query("SELECT SUM(totalPrice) FROM customer_orders WHERE status IN ('PAYMENT_VERIFIED', 'SHIPPED', 'COMPLETED')")
    fun getTotalRevenue(): Flow<Double?>

    @Query("SELECT * FROM customer_orders WHERE LOWER(customerName) = LOWER(:customerName) ORDER BY orderDate DESC")
    suspend fun getCustomerOrders(customerName: String): List<CustomerOrder>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: CustomerOrder): Long

    @Update
    suspend fun updateOrder(order: CustomerOrder)

    @Query("UPDATE customer_orders SET status = :status WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: Long, status: String)

    @Delete
    suspend fun deleteOrder(order: CustomerOrder)

    @Query("DELETE FROM customer_orders")
    suspend fun clearAllOrders()
}
