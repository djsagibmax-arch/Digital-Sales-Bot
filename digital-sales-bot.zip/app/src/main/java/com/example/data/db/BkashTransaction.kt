package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bkash_transactions")
data class BkashTransaction(
    @PrimaryKey
    val trxId: String, // e.g. "9X38A7K1"
    val senderPhone: String, // e.g. "01711223344"
    val amount: Double, // e.g. 1850.0
    val paymentMethod: String = "bKash", // "bKash", "Nagad", "Rocket"
    val isClaimed: Boolean = false, // true once linked to an order
    val receivedTimestamp: Long = System.currentTimeMillis()
)
