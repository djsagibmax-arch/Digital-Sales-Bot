package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customer_orders")
data class CustomerOrder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderId: String, // e.g. "#ORD-4829"
    val customerName: String,
    val customerPhone: String,
    val deliveryAddress: String,
    val productCode: String,
    val productName: String,
    val totalPrice: Double,
    val paymentMethod: String, // "bKash", "Nagad", "Rocket", "Cash on Delivery"
    val trxId: String, // Transaction ID or sender phone number
    val status: String = STATUS_PENDING, // PENDING, PAYMENT_VERIFIED, SHIPPED, COMPLETED, CANCELLED
    val platform: String, // WhatsApp, Messenger, SMS, Telegram
    val orderDate: Long = System.currentTimeMillis(),
    val notes: String = ""
) {
    companion object {
        const val STATUS_PENDING = "PENDING"
        const val STATUS_VERIFIED = "PAYMENT_VERIFIED"
        const val STATUS_SHIPPED = "SHIPPED"
        const val STATUS_COMPLETED = "COMPLETED"
        const val STATUS_CANCELLED = "CANCELLED"
    }
}
