package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SalesLeadDao {
    @Query("SELECT * FROM sales_leads ORDER BY timestamp DESC")
    fun getAllLeads(): Flow<List<SalesLead>>

    @Query("SELECT COUNT(*) FROM sales_leads")
    fun getLeadsCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLead(lead: SalesLead): Long

    @Query("SELECT * FROM sales_leads WHERE LOWER(senderName) = LOWER(:senderName) ORDER BY timestamp ASC")
    suspend fun getCustomerLeads(senderName: String): List<SalesLead>

    @Query("SELECT COUNT(*) FROM sales_leads WHERE LOWER(senderName) = LOWER(:senderName)")
    suspend fun getCustomerMessageCount(senderName: String): Int

    @Delete
    suspend fun deleteLead(lead: SalesLead)

    @Query("DELETE FROM sales_leads")
    suspend fun clearAllLeads()
}
