package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sales_leads")
data class SalesLead(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val senderName: String,
    val platform: String, // WhatsApp, Messenger, SMS, Telegram, Simulator
    val incomingMessage: String,
    val botReply: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "AUTO_REPLIED", // AUTO_REPLIED, AI_REPLIED, NO_MATCH
    val matchedKeyword: String = ""
)
