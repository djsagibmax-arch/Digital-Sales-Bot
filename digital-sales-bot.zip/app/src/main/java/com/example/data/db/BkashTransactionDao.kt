package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BkashTransactionDao {
    @Query("SELECT * FROM bkash_transactions ORDER BY receivedTimestamp DESC")
    fun getAllBkashTransactions(): Flow<List<BkashTransaction>>

    @Query("SELECT * FROM bkash_transactions WHERE trxId = :trxId LIMIT 1")
    suspend fun getTransactionByTrxId(trxId: String): BkashTransaction?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTransaction(transaction: BkashTransaction): Long

    @Query("UPDATE bkash_transactions SET isClaimed = 1 WHERE trxId = :trxId")
    suspend fun markClaimed(trxId: String)

    @Query("DELETE FROM bkash_transactions")
    suspend fun clearAll()
}
