package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.api.AiClient
import com.example.data.db.*
import kotlinx.coroutines.flow.Flow

class SalesRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val ruleDao = db.autoReplyRuleDao()
    private val productDao = db.productDao()
    private val leadDao = db.salesLeadDao()
    private val orderDao = db.customerOrderDao()
    private val bkashDao = db.bkashTransactionDao()

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sales_bot_prefs", Context.MODE_PRIVATE)

    // Data Flows
    val allRules: Flow<List<AutoReplyRule>> = ruleDao.getAllRules()
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val allLeads: Flow<List<SalesLead>> = leadDao.getAllLeads()
    val leadsCount: Flow<Int> = leadDao.getLeadsCount()
    val allOrders: Flow<List<CustomerOrder>> = orderDao.getAllOrders()
    val pendingOrdersCount: Flow<Int> = orderDao.getPendingOrdersCount()
    val totalRevenue: Flow<Double?> = orderDao.getTotalRevenue()
    val allBkashTransactions: Flow<List<BkashTransaction>> = bkashDao.getAllBkashTransactions()

    // Settings
    var isBotActive: Boolean
        get() = prefs.getBoolean("is_bot_active", true)
        set(value) = prefs.edit().putBoolean("is_bot_active", value).apply()

    var isAiEnabled: Boolean
        get() = prefs.getBoolean("is_ai_enabled", true)
        set(value) = prefs.edit().putBoolean("is_ai_enabled", value).apply()

    var replyDelaySeconds: Int
        get() = prefs.getInt("reply_delay_sec", 1)
        set(value) = prefs.edit().putInt("reply_delay_sec", value).apply()

    var customPrompt: String
        get() = prefs.getString("custom_prompt", "কাস্টমারকে সর্বদা 'স্যার' বা 'ম্যাডাম' বলে সম্বোধন করুন। কাস্টমারের ব্যক্তিগত নাম ধরে ডাকা যাবে না। আকর্ষণীয়ভাবে প্রোডাক্ট উপস্থাপন করে সেলস জেনারেট করুন এবং পেমেন্টের জন্য সেন মানি (Send Money) করতে বলুন। টাকা পাঠানোর পর গ্রাহকের নম্বর, ট্রানজেকশন আইডি (TrxID) ও ডেলিভারি ঠিকানা চান। কোনো বাড়তী কথা না বলে শর্টকাট ও সুন্দরভাবে প্রশ্নের উত্তর দিন।") ?: ""
        set(value) = prefs.edit().putString("custom_prompt", value).apply()

    var customApiKey: String
        get() = prefs.getString("custom_api_key", "") ?: ""
        set(value) = prefs.edit().putString("custom_api_key", value).apply()

    // AI Provider Settings
    var aiProvider: String
        get() = prefs.getString("ai_provider", "Gemini") ?: "Gemini"
        set(value) = prefs.edit().putString("ai_provider", value).apply()

    var geminiApiKey: String
        get() = prefs.getString("gemini_api_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_api_key", value).apply()

    var geminiModel: String
        get() = prefs.getString("gemini_model", "gemini-3.5-flash") ?: "gemini-3.5-flash"
        set(value) = prefs.edit().putString("gemini_model", value).apply()

    var groqApiKey: String
        get() = prefs.getString("groq_api_key", "") ?: ""
        set(value) = prefs.edit().putString("groq_api_key", value).apply()

    var groqModel: String
        get() = prefs.getString("groq_model", "llama-3.1-8b-instant") ?: "llama-3.1-8b-instant"
        set(value) = prefs.edit().putString("groq_model", value).apply()

    var chatgptApiKey: String
        get() = prefs.getString("chatgpt_api_key", "") ?: ""
        set(value) = prefs.edit().putString("chatgpt_api_key", value).apply()

    var chatgptModel: String
        get() = prefs.getString("chatgpt_model", "gpt-4o-mini") ?: "gpt-4o-mini"
        set(value) = prefs.edit().putString("chatgpt_model", value).apply()

    var whatsappEnabled: Boolean
        get() = prefs.getBoolean("target_whatsapp", true)
        set(value) = prefs.edit().putBoolean("target_whatsapp", value).apply()

    var messengerEnabled: Boolean
        get() = prefs.getBoolean("target_messenger", true)
        set(value) = prefs.edit().putBoolean("target_messenger", value).apply()

    var smsEnabled: Boolean
        get() = prefs.getBoolean("target_sms", true)
        set(value) = prefs.edit().putBoolean("target_sms", value).apply()

    var telegramEnabled: Boolean
        get() = prefs.getBoolean("target_telegram", true)
        set(value) = prefs.edit().putBoolean("target_telegram", value).apply()

    // MFS Payment Methods Settings
    var isAutoFollowupEnabled: Boolean
        get() = prefs.getBoolean("is_auto_followup_enabled", false)
        set(value) = prefs.edit().putBoolean("is_auto_followup_enabled", value).apply()

    var autoFollowupMessage: String
        get() = prefs.getString("auto_followup_message", "ধন্যবাদ! যেকোনো সহযোগিতার জন্য আমাদের সাথে যোগাযোগ করুন।") ?: ""
        set(value) = prefs.edit().putString("auto_followup_message", value).apply()

    var autoFollowupTrigger: String // "CUSTOMER", "ROBOT", or "BOTH"
        get() = prefs.getString("auto_followup_trigger", "BOTH") ?: "BOTH"
        set(value) = prefs.edit().putString("auto_followup_trigger", value).apply()

    var autoFollowupDelaySeconds: Int
        get() = prefs.getInt("auto_followup_delay_sec", 5)
        set(value) = prefs.edit().putInt("auto_followup_delay_sec", value).apply()

    var isBkashEnabled: Boolean
        get() = prefs.getBoolean("is_bkash_enabled", true)
        set(value) = prefs.edit().putBoolean("is_bkash_enabled", value).apply()

    var bkashNumber: String
        get() = prefs.getString("bkash_number", "") ?: ""
        set(value) = prefs.edit().putString("bkash_number", value).apply()

    var isNagadEnabled: Boolean
        get() = prefs.getBoolean("is_nagad_enabled", true)
        set(value) = prefs.edit().putBoolean("is_nagad_enabled", value).apply()

    var nagadNumber: String
        get() = prefs.getString("nagad_number", "") ?: ""
        set(value) = prefs.edit().putString("nagad_number", value).apply()

    var isRocketEnabled: Boolean
        get() = prefs.getBoolean("is_rocket_enabled", false)
        set(value) = prefs.edit().putBoolean("is_rocket_enabled", value).apply()

    var rocketNumber: String
        get() = prefs.getString("rocket_number", "") ?: ""
        set(value) = prefs.edit().putString("rocket_number", value).apply()

    // Database Actions
    suspend fun insertRule(rule: AutoReplyRule): Long = ruleDao.insertRule(rule)
    suspend fun updateRule(rule: AutoReplyRule) = ruleDao.updateRule(rule)
    suspend fun deleteRule(rule: AutoReplyRule) = ruleDao.deleteRule(rule)

    suspend fun insertProduct(product: Product): Long = productDao.insertProduct(product)
    suspend fun updateProduct(product: Product) = productDao.updateProduct(product)
    suspend fun deleteProduct(product: Product) = productDao.deleteProduct(product)

    suspend fun purgeDummyProducts() {
        val dummyCodes = listOf("P101", "P102", "P103")
        val allProducts = productDao.getAvailableProducts()
        allProducts.forEach { p ->
            if (dummyCodes.contains(p.code) || p.name.contains("Smart Wireless Headphones") || p.name.contains("Premium Sales CRM Software") || p.name.contains("Smart Fitness Watch")) {
                productDao.deleteProduct(p)
            }
        }
    }

    suspend fun insertLead(lead: SalesLead): Long = leadDao.insertLead(lead)
    suspend fun clearLeads() = leadDao.clearAllLeads()

    // Order & Payment Actions
    suspend fun insertOrder(order: CustomerOrder): Long = orderDao.insertOrder(order)
    suspend fun updateOrderStatus(orderId: Long, status: String) = orderDao.updateOrderStatus(orderId, status)
    suspend fun deleteOrder(order: CustomerOrder) = orderDao.deleteOrder(order)
    suspend fun clearOrders() = orderDao.clearAllOrders()

    suspend fun insertBkashTransaction(tx: BkashTransaction): Long = bkashDao.insertTransaction(tx)

    private fun appendAutoFollowupIfNeeded(rawReply: String, isBotReplyGenerated: Boolean): String {
        if (!isAutoFollowupEnabled) return rawReply
        val followupText = autoFollowupMessage.trim()
        if (followupText.isBlank()) return rawReply

        val shouldSend = when (autoFollowupTrigger) {
            "CUSTOMER" -> true
            "ROBOT" -> isBotReplyGenerated
            "BOTH" -> true
            else -> true
        }

        if (!shouldSend) return rawReply

        return if (rawReply.isNotBlank()) {
            "$rawReply\n\n$followupText"
        } else {
            followupText
        }
    }

    // Core Matching Engine
    suspend fun processIncomingMessage(senderName: String, platform: String, messageText: String): String {
        val trimmed = messageText.trim().lowercase()
        val activeRules = ruleDao.getActiveRulesList()

        // 0. Smart Order & Payment Auto-Detection
        val isPaymentOrOrderIntent = trimmed.contains("bkash") || trimmed.contains("বিকাশ") ||
                trimmed.contains("nagad") || trimmed.contains("নগদ") ||
                trimmed.contains("rocket") || trimmed.contains("রকেট") ||
                trimmed.contains("trx") || trimmed.contains("trxid") ||
                trimmed.contains("অর্ডার") || trimmed.contains("order") ||
                trimmed.contains("ঠিকানা") || trimmed.contains("পেমেন্ট") ||
                trimmed.contains("টাকা") || trimmed.contains("দিছি") ||
                trimmed.contains("পাঠাইছি") || trimmed.contains("পাঠিয়েছি") ||
                trimmed.contains("কিনব") || trimmed.contains("চাই") ||
                trimmed.contains("01")

        if (isPaymentOrOrderIntent) {
            val phoneRegex = Regex("01[3-9][0-9\\s-]{8,11}")
            val phoneMatchRaw = phoneRegex.find(messageText)?.value
            val phoneMatch = phoneMatchRaw?.replace(Regex("[^0-9]"), "")?.let {
                if (it.length == 11) it else null
            } ?: "ফোন নম্বর সংগৃহীত হয়নি"

            val paymentMethod = when {
                trimmed.contains("nagad") || trimmed.contains("নগদ") -> "Nagad"
                trimmed.contains("rocket") || trimmed.contains("রকেট") -> "Rocket"
                trimmed.contains("bkash") || trimmed.contains("বিকাশ") -> "bKash"
                else -> "bKash"
            }

            val trxRegex = Regex("([A-Za-z0-9]{8,12})")
            val trxMatch = trxRegex.findAll(messageText)
                .map { it.value.uppercase() }
                .firstOrNull { candidate ->
                    candidate.length >= 8 &&
                            !candidate.startsWith("01") &&
                            !candidate.contains("HEADPHONES", ignoreCase = true) &&
                            !candidate.contains("SMART", ignoreCase = true)
                } ?: "N/A"

            val products = productDao.getAvailableProducts()
            val matchedProduct = products.firstOrNull { p ->
                trimmed.contains(p.code.lowercase()) ||
                        trimmed.contains(p.name.lowercase()) ||
                        p.name.lowercase().split(" ").any { word -> word.length > 3 && trimmed.contains(word) }
            } ?: products.firstOrNull()

            // Check if TrxID matches an actual received bKash / Nagad payment SMS in database
            val bkashTx = if (trxMatch != "N/A") bkashDao.getTransactionByTrxId(trxMatch) else null
            val isVerified = bkashTx != null

            val orderStatus = if (isVerified) CustomerOrder.STATUS_VERIFIED else CustomerOrder.STATUS_PENDING
            val generatedOrderId = "#ORD-${(1000..9999).random()}"

            val newOrder = CustomerOrder(
                orderId = generatedOrderId,
                customerName = senderName,
                customerPhone = phoneMatch,
                deliveryAddress = if (messageText.length > 15) messageText.take(120) else "মেসেজ হতে সংগৃহীত",
                productCode = matchedProduct?.code ?: "ITEM",
                productName = matchedProduct?.name ?: "সাধারণ আইটেম",
                totalPrice = matchedProduct?.price ?: 0.0,
                paymentMethod = paymentMethod,
                trxId = trxMatch,
                status = orderStatus,
                platform = platform
            )

            orderDao.insertOrder(newOrder)
            if (isVerified && trxMatch != "N/A") {
                bkashDao.markClaimed(trxMatch)
            }

            val downloadUrl = matchedProduct?.buyUrl?.ifBlank { null }
                ?: "অ্যাডমিনের সাথে যোগাযোগ করুন"

            val activeBkashNum = matchedProduct?.bkashNumber?.ifBlank { bkashNumber } ?: bkashNumber
            val activeNagadNum = matchedProduct?.nagadNumber?.ifBlank { nagadNumber } ?: nagadNumber
            val activeRocketNum = matchedProduct?.rocketNumber?.ifBlank { rocketNumber } ?: rocketNumber

            val paymentMethodsText = buildString {
                if (isBkashEnabled) {
                    val numStr = if (activeBkashNum.isNotBlank()) activeBkashNum else "নম্বর সেটিংসে যুক্ত করা হয়নি (প্রতিনিধির কথা অপেক্ষা করুন)"
                    append("• 🌸 বিকাশ (bKash): $numStr\n")
                }
                if (isNagadEnabled) {
                    val numStr = if (activeNagadNum.isNotBlank()) activeNagadNum else "নম্বর সেটিংসে যুক্ত করা হয়নি (প্রতিনিধির কথা অপেক্ষা করুন)"
                    append("• 🟠 নগদ (Nagad): $numStr\n")
                }
                if (isRocketEnabled) {
                    val numStr = if (activeRocketNum.isNotBlank()) activeRocketNum else "নম্বর সেটিংসে যুক্ত করা হয়নি (প্রতিনিধির কথা অপেক্ষা করুন)"
                    append("• 🚀 রকেট (Rocket): $numStr\n")
                }
            }.ifBlank { "অনুগ্রহ করে আমাদের পেজের অ্যাডমিন/প্রতিনিধির কাছ থেকে পেমেন্ট নম্বরটি জেনে নিন।" }

            val rawReply = if (isVerified) {
                "✅ **পেমেন্ট ভেরিফাইড ও অর্ডার কনফার্মড!** 🎉\n\n" +
                        "ধন্যবাদ $senderName! আপনার ট্রানজেকশন ID ($trxMatch) টি আমাদের পেমেন্ট মেসেজের সাথে মিলিয়ে ভেরিফাই করা হয়েছে।\n\n" +
                        "📦 **অর্ডার আইডি:** $generatedOrderId\n" +
                        "🛒 **পণ্য:** ${newOrder.productName} (৳${newOrder.totalPrice})\n" +
                        "💳 **পেমেন্ট মাধ্যম:** $paymentMethod\n" +
                        "📲 **ফোন:** $phoneMatch\n\n" +
                        "📥 **আপনার কাঙ্ক্ষিত ডিজিটাল প্রোডাক্ট/ড্রাইভ ফাইল লিংক:**\n$downloadUrl\n\n" +
                        "📌 আপনার সমস্ত তথ্য কাস্টমার নোটে সেভ করা হয়েছে।"
            } else if (trxMatch != "N/A") {
                "⚠️ **পেমেন্ট তথ্য সংগৃহীত হয়েছে (যাচাইকরণের অপেক্ষায়)**\n\n" +
                        "ধন্যবাদ $senderName! আপনার TrxID: $trxMatch সিস্টেমে যুক্ত হয়েছে।\n\n" +
                        "📌 **পেমেন্ট ভেরিফিকেশন স্টেটাস:**\n" +
                        "আমাদের বিকাশ/নগদ ইনবক্সে আপনার TrxID টি ম্যাচ করা হচ্ছে। মেসেজ মিললেই এটি অটো-ভেরিফাই হয়ে যাবে এবং গুগল ড্রাইভ/ফাইল লিংক চলে আসবে!\n\n" +
                        "📦 **অর্ডার আইডি:** $generatedOrderId\n" +
                        "🛒 **পণ্য:** ${newOrder.productName} (৳${newOrder.totalPrice})\n" +
                        "📲 **কাস্টমার ফোন:** $phoneMatch\n\n" +
                        "📌 আপনার বিবরণ অর্ডার নোটসে সেভ করা হয়েছে।"
            } else {
                "✅ **অর্ডার তথ্য তৈরি হয়েছে**\n\n" +
                        "ধন্যবাদ $senderName! পণ্য: ${newOrder.productName} (৳${newOrder.totalPrice})\n\n" +
                        "💳 **পেমেন্ট সেন্ড-মানি নাম্বারসমূহ:**\n" +
                        paymentMethodsText.trimEnd() + "\n\n" +
                        "টাকা পাঠানোর পর প্রাপ্ত TrxID টি আমাদের লিখে মেসেজ দিন। TrxID মিললেই সাথে সাথে ড্রাইভ লিংক পেয়ে যাবেন!"
            }

            val finalReply = appendAutoFollowupIfNeeded(rawReply, isBotReplyGenerated = true)
            leadDao.insertLead(SalesLead(
                senderName = senderName,
                platform = platform,
                incomingMessage = messageText,
                botReply = finalReply,
                status = if (isVerified) "PAYMENT_VERIFIED" else "ORDER_CREATED",
                matchedKeyword = generatedOrderId
            ))
            return finalReply
        }

        // 1. Try exact match first
        for (rule in activeRules) {
            if (rule.matchType == AutoReplyRule.MATCH_EXACT && trimmed == rule.keyword.lowercase()) {
                ruleDao.incrementUsage(rule.id)
                val rawReply = rule.response
                val finalReply = appendAutoFollowupIfNeeded(rawReply, isBotReplyGenerated = true)
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = finalReply,
                    status = "AUTO_REPLIED",
                    matchedKeyword = rule.keyword
                ))
                return finalReply
            }
        }

        // 2. Try contains match
        for (rule in activeRules) {
            if (rule.matchType == AutoReplyRule.MATCH_CONTAINS && trimmed.contains(rule.keyword.lowercase())) {
                ruleDao.incrementUsage(rule.id)
                val rawReply = rule.response
                val finalReply = appendAutoFollowupIfNeeded(rawReply, isBotReplyGenerated = true)
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = finalReply,
                    status = "AUTO_REPLIED",
                    matchedKeyword = rule.keyword
                ))
                return finalReply
            }
        }

        // 3. Try Product match by code or name
        val products = productDao.getAvailableProducts()
        for (product in products) {
            if (trimmed.contains(product.code.lowercase()) || trimmed.contains(product.name.lowercase())) {
                val paymentDetails = buildString {
                    if (isBkashEnabled && bkashNumber.isNotBlank()) append("\n• বিকাশ (Send Money): $bkashNumber")
                    if (isNagadEnabled && nagadNumber.isNotBlank()) append("\n• নগদ (Send Money): $nagadNumber")
                    if (isRocketEnabled && rocketNumber.isNotBlank()) append("\n• রকেট (Send Money): $rocketNumber")
                }
                val rawReply = "হ্যালো স্যার/ম্যাডাম! আমাদের '${product.name}' প্রডাক্টটির বিশেষ মূল্য মাত্র ৳${product.price.toInt()}।\n" +
                        "${if (product.description.isNotBlank()) "পণ্য বিবরণ: ${product.description}\n" else ""}\n" +
                        "অর্ডারটি কনফার্ম করতে আমাদের নম্বরে সেন মানি (Send Money) করে আপনার বিকাশ/নগদ নম্বর, ট্রানজেকশন আইডি (TrxID) এবং ডেলিভারি ঠিকানা জানান, স্যার।$paymentDetails"
                val finalReply = appendAutoFollowupIfNeeded(rawReply, isBotReplyGenerated = true)
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = finalReply,
                    status = "PRODUCT_MATCH",
                    matchedKeyword = product.code
                ))
                return finalReply
            }
        }

        // 4. Multi-Provider AI Fallback if enabled
        if (isAiEnabled) {
            val activeProducts = products.filter { it.isAvailable }
            val multiProductNotice = if (activeProducts.size > 1) {
                "⚠️ MULTI-PRODUCT CATALOG NOTICE (${activeProducts.size} ACTIVE PRODUCTS AVAILABLE IN STORE):\n" +
                "There are ${activeProducts.size} active products in this catalog. UNLESS the customer has already specified or chosen a specific product in their current message or chat history, you MUST list the available products (Name & Price) to the customer and ask which product they are interested in buying!\n\n"
            } else ""

            val productContext = if (products.isEmpty()) {
                "⚠️ STORE CATALOG NOTICE: Currently there are NO products added in the store catalog. Do NOT invent, advertise, or market any fake or imaginary products. If the customer asks about products or pricing, politely inform them that products will be added soon or ask what product or service they are inquiring about."
            } else {
                multiProductNotice + products.joinToString("\n\n") { p ->
                    val botStatus = if (p.isAvailable) "BOT MARKETING ACTIVE (Pitch and promote to customers!)" else "BOT MARKETING DISABLED (Do not offer this product)"
                    "• Product Name: ${p.name}\n" +
                    "  Product Code: ${p.code} | Price: ৳${p.price.toInt()} | Stock: ${p.stock} | Category: ${p.category}\n" +
                    "  Marketing Status: $botStatus\n" +
                    "  FULL PRODUCT DESCRIPTION & SPECIFICATIONS FOR MARKETING:\n  ${if (p.description.isNotBlank()) p.description else "Product details."}\n" +
                    "  DIGITAL DELIVERABLE LINK / FILE: ${if (p.buyUrl.isNotBlank()) p.buyUrl else "Contact store admin"}"
                }
            }

            val paymentMethodsContext = buildString {
                append("Official Enabled Payment Methods and Numbers:\n")
                if (isBkashEnabled) {
                    append("- bKash (বিকাশ): ").append(if (bkashNumber.isNotBlank()) bkashNumber else "NO official number configured. Do NOT invent a number, tell customer to contact page admin.").append("\n")
                } else {
                    append("- bKash: DISABLED (Do not offer bKash).\n")
                }
                if (isNagadEnabled) {
                    append("- Nagad (নগদ): ").append(if (nagadNumber.isNotBlank()) nagadNumber else "NO official number configured. Do NOT invent a number, tell customer to contact page admin.").append("\n")
                } else {
                    append("- Nagad: DISABLED (Do not offer Nagad).\n")
                }
                if (isRocketEnabled) {
                    append("- Rocket (রকেট): ").append(if (rocketNumber.isNotBlank()) rocketNumber else "NO official number configured. Do NOT invent a number, tell customer to contact page admin.").append("\n")
                } else {
                    append("- Rocket: DISABLED (Do not offer Rocket).\n")
                }
            }

            // Customer History & Memory Retrieval
            val pastLeads = leadDao.getCustomerLeads(senderName)
            val pastInteractionsCount = pastLeads.size
            val isReturningCustomer = pastInteractionsCount > 0

            val chatHistoryContext = if (pastLeads.isNotEmpty()) {
                buildString {
                    append("--- PREVIOUS CHAT HISTORY WITH CUSTOMER '$senderName' (Total Previous Conversations: $pastInteractionsCount) ---\n")
                    pastLeads.takeLast(8).forEachIndexed { idx, lead ->
                        append("[Past Message #${idx + 1}]\n")
                        append("Customer ($senderName): ${lead.incomingMessage}\n")
                        append("Bot Reply: ${lead.botReply}\n")
                    }
                    append("--- END OF CHAT HISTORY ---")
                }
            } else {
                "--- NO PREVIOUS CHAT HISTORY (This is a brand new customer) ---"
            }

            val pastOrders = orderDao.getCustomerOrders(senderName)
            val ordersHistoryContext = if (pastOrders.isNotEmpty()) {
                buildString {
                    append("--- RECORDED ORDERS FOR '$senderName' ---\n")
                    pastOrders.take(5).forEach { ord ->
                        append("Order ID: ${ord.orderId} | Product: ${ord.productName} (৳${ord.totalPrice}) | Status: ${ord.status} | TrxID: ${ord.trxId}\n")
                    }
                    append("--- END OF ORDERS ---")
                }
            } else {
                "--- NO PREVIOUS ORDERS RECORDED ---"
            }

            val currentProvider = aiProvider
            val (activeApiKey, activeModel) = when (currentProvider) {
                "Groq" -> Pair(groqApiKey.ifBlank { customApiKey }, groqModel.ifBlank { "llama-3.1-8b-instant" })
                "ChatGPT" -> Pair(chatgptApiKey.ifBlank { customApiKey }, chatgptModel.ifBlank { "gpt-4o-mini" })
                else -> Pair(geminiApiKey.ifBlank { customApiKey }, geminiModel.ifBlank { "gemini-3.1-flash-lite" })
            }

            val rawAiReply = AiClient.generateSalesReply(
                provider = currentProvider,
                modelName = activeModel,
                apiKeyOverride = activeApiKey,
                customerName = senderName,
                platform = platform,
                isReturningCustomer = isReturningCustomer,
                customerMessage = messageText,
                productCatalogContext = productContext,
                paymentMethodsContext = paymentMethodsContext,
                chatHistoryContext = chatHistoryContext,
                ordersHistoryContext = ordersHistoryContext,
                customPrompt = customPrompt
            )
            val finalAiReply = appendAutoFollowupIfNeeded(rawAiReply, isBotReplyGenerated = true)
            leadDao.insertLead(SalesLead(
                senderName = senderName,
                platform = platform,
                incomingMessage = messageText,
                botReply = finalAiReply,
                status = "AI_REPLIED",
                matchedKeyword = "$currentProvider ($activeModel)"
            ))
            return finalAiReply
        }

        // Default fallback response
        val fallbackReply = "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি শীঘ্রই উত্তর দেবে।"
        val finalFallbackReply = appendAutoFollowupIfNeeded(fallbackReply, isBotReplyGenerated = false)
        leadDao.insertLead(SalesLead(
            senderName = senderName,
            platform = platform,
            incomingMessage = messageText,
            botReply = finalFallbackReply,
            status = "DEFAULT_REPLIED",
            matchedKeyword = "None"
        ))
        return finalFallbackReply
    }
}
