package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.api.GeminiClient
import com.example.data.db.*
import kotlinx.coroutines.flow.Flow

class SalesRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val ruleDao = db.autoReplyRuleDao()
    private val productDao = db.productDao()
    private val leadDao = db.salesLeadDao()

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sales_bot_prefs", Context.MODE_PRIVATE)

    // Data Flows
    val allRules: Flow<List<AutoReplyRule>> = ruleDao.getAllRules()
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val allLeads: Flow<List<SalesLead>> = leadDao.getAllLeads()
    val leadsCount: Flow<Int> = leadDao.getLeadsCount()

    // Settings
    var isBotActive: Boolean
        get() = prefs.getBoolean("is_bot_active", true)
        set(value) = prefs.edit().putBoolean("is_bot_active", value).apply()

    var isAiEnabled: Boolean
        get() = prefs.getBoolean("is_ai_enabled", true)
        set(value) = prefs.edit().putBoolean("is_ai_enabled", value).apply()

    var replyDelaySeconds: Int
        get() = prefs.getInt("reply_delay_sec", 1)
        set(value) = prefs.edit().putInt("reply_delay_sec", value).apply()

    var customPrompt: String
        get() = prefs.getString("custom_prompt", "Provide friendly customer support and sales assistance.") ?: ""
        set(value) = prefs.edit().putString("custom_prompt", value).apply()

    var customApiKey: String
        get() = prefs.getString("custom_api_key", "") ?: ""
        set(value) = prefs.edit().putString("custom_api_key", value).apply()

    var whatsappEnabled: Boolean
        get() = prefs.getBoolean("target_whatsapp", true)
        set(value) = prefs.edit().putBoolean("target_whatsapp", value).apply()

    var messengerEnabled: Boolean
        get() = prefs.getBoolean("target_messenger", true)
        set(value) = prefs.edit().putBoolean("target_messenger", value).apply()

    var smsEnabled: Boolean
        get() = prefs.getBoolean("target_sms", true)
        set(value) = prefs.edit().putBoolean("target_sms", value).apply()

    var telegramEnabled: Boolean
        get() = prefs.getBoolean("target_telegram", true)
        set(value) = prefs.edit().putBoolean("target_telegram", value).apply()

    // Database Actions
    suspend fun insertRule(rule: AutoReplyRule): Long = ruleDao.insertRule(rule)
    suspend fun updateRule(rule: AutoReplyRule) = ruleDao.updateRule(rule)
    suspend fun deleteRule(rule: AutoReplyRule) = ruleDao.deleteRule(rule)

    suspend fun insertProduct(product: Product): Long = productDao.insertProduct(product)
    suspend fun updateProduct(product: Product) = productDao.updateProduct(product)
    suspend fun deleteProduct(product: Product) = productDao.deleteProduct(product)

    suspend fun insertLead(lead: SalesLead): Long = leadDao.insertLead(lead)
    suspend fun clearLeads() = leadDao.clearAllLeads()

    // Core Matching Engine
    suspend fun processIncomingMessage(senderName: String, platform: String, messageText: String): String {
        val trimmed = messageText.trim().lowercase()
        val activeRules = ruleDao.getActiveRulesList()

        // 1. Try exact match first
        for (rule in activeRules) {
            if (rule.matchType == AutoReplyRule.MATCH_EXACT && trimmed == rule.keyword.lowercase()) {
                ruleDao.incrementUsage(rule.id)
                val reply = rule.response
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = reply,
                    status = "AUTO_REPLIED",
                    matchedKeyword = rule.keyword
                ))
                return reply
            }
        }

        // 2. Try contains match
        for (rule in activeRules) {
            if (rule.matchType == AutoReplyRule.MATCH_CONTAINS && trimmed.contains(rule.keyword.lowercase())) {
                ruleDao.incrementUsage(rule.id)
                val reply = rule.response
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = reply,
                    status = "AUTO_REPLIED",
                    matchedKeyword = rule.keyword
                ))
                return reply
            }
        }

        // 3. Try Product match by code or name
        val products = productDao.getAvailableProducts()
        for (product in products) {
            if (trimmed.contains(product.code.lowercase()) || trimmed.contains(product.name.lowercase())) {
                val reply = "পণ্য: ${product.name}\nমূল্য: ৳${product.price}\nবিবরণ: ${product.description}\nঅর্ডার লিংক: ${product.buyUrl.ifBlank { "মেসেজে আপনার ঠিকানা দিন" }}"
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = reply,
                    status = "PRODUCT_MATCH",
                    matchedKeyword = product.code
                ))
                return reply
            }
        }

        // 4. Gemini AI Fallback if enabled
        if (isAiEnabled) {
            val productContext = products.joinToString("\n") { p ->
                "- ${p.name} (Code: ${p.code}): ৳${p.price}. ${p.description}"
            }
            val aiReply = GeminiClient.generateSalesReply(
                customerMessage = messageText,
                productCatalogContext = productContext,
                customPrompt = customPrompt,
                apiKeyOverride = customApiKey
            )
            leadDao.insertLead(SalesLead(
                senderName = senderName,
                platform = platform,
                incomingMessage = messageText,
                botReply = aiReply,
                status = "AI_REPLIED",
                matchedKeyword = "Gemini AI"
            ))
            return aiReply
        }

        // Default fallback response
        val fallbackReply = "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি শীঘ্রই উত্তর দেবে।"
        leadDao.insertLead(SalesLead(
            senderName = senderName,
            platform = platform,
            incomingMessage = messageText,
            botReply = fallbackReply,
            status = "DEFAULT_REPLIED",
            matchedKeyword = "None"
        ))
        return fallbackReply
    }
}
