package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.api.AiClient
import com.example.data.db.*
import kotlinx.coroutines.flow.Flow

class SalesRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val ruleDao = db.autoReplyRuleDao()
    private val productDao = db.productDao()
    private val leadDao = db.salesLeadDao()
    private val orderDao = db.customerOrderDao()
    private val bkashDao = db.bkashTransactionDao()

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sales_bot_prefs", Context.MODE_PRIVATE)

    // Data Flows
    val allRules: Flow<List<AutoReplyRule>> = ruleDao.getAllRules()
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val allLeads: Flow<List<SalesLead>> = leadDao.getAllLeads()
    val leadsCount: Flow<Int> = leadDao.getLeadsCount()
    val allOrders: Flow<List<CustomerOrder>> = orderDao.getAllOrders()
    val pendingOrdersCount: Flow<Int> = orderDao.getPendingOrdersCount()
    val totalRevenue: Flow<Double?> = orderDao.getTotalRevenue()
    val allBkashTransactions: Flow<List<BkashTransaction>> = bkashDao.getAllBkashTransactions()

    // Settings
    var isBotActive: Boolean
        get() = prefs.getBoolean("is_bot_active", true)
        set(value) = prefs.edit().putBoolean("is_bot_active", value).apply()

    var isAiEnabled: Boolean
        get() = prefs.getBoolean("is_ai_enabled", true)
        set(value) = prefs.edit().putBoolean("is_ai_enabled", value).apply()

    var replyDelaySeconds: Int
        get() = prefs.getInt("reply_delay_sec", 1)
        set(value) = prefs.edit().putInt("reply_delay_sec", value).apply()

    var customPrompt: String
        get() = prefs.getString("custom_prompt", "Provide friendly customer support and sales assistance.") ?: ""
        set(value) = prefs.edit().putString("custom_prompt", value).apply()

    var customApiKey: String
        get() = prefs.getString("custom_api_key", "") ?: ""
        set(value) = prefs.edit().putString("custom_api_key", value).apply()

    // AI Provider Settings
    var aiProvider: String
        get() = prefs.getString("ai_provider", "Gemini") ?: "Gemini"
        set(value) = prefs.edit().putString("ai_provider", value).apply()

    var geminiApiKey: String
        get() = prefs.getString("gemini_api_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_api_key", value).apply()

    var geminiModel: String
        get() = prefs.getString("gemini_model", "gemini-3.1-flash-lite") ?: "gemini-3.1-flash-lite"
        set(value) = prefs.edit().putString("gemini_model", value).apply()

    var groqApiKey: String
        get() = prefs.getString("groq_api_key", "") ?: ""
        set(value) = prefs.edit().putString("groq_api_key", value).apply()

    var groqModel: String
        get() = prefs.getString("groq_model", "llama-3.1-8b-instant") ?: "llama-3.1-8b-instant"
        set(value) = prefs.edit().putString("groq_model", value).apply()

    var chatgptApiKey: String
        get() = prefs.getString("chatgpt_api_key", "") ?: ""
        set(value) = prefs.edit().putString("chatgpt_api_key", value).apply()

    var chatgptModel: String
        get() = prefs.getString("chatgpt_model", "gpt-4o-mini") ?: "gpt-4o-mini"
        set(value) = prefs.edit().putString("chatgpt_model", value).apply()

    var whatsappEnabled: Boolean
        get() = prefs.getBoolean("target_whatsapp", true)
        set(value) = prefs.edit().putBoolean("target_whatsapp", value).apply()

    var messengerEnabled: Boolean
        get() = prefs.getBoolean("target_messenger", true)
        set(value) = prefs.edit().putBoolean("target_messenger", value).apply()

    var smsEnabled: Boolean
        get() = prefs.getBoolean("target_sms", true)
        set(value) = prefs.edit().putBoolean("target_sms", value).apply()

    var telegramEnabled: Boolean
        get() = prefs.getBoolean("target_telegram", true)
        set(value) = prefs.edit().putBoolean("target_telegram", value).apply()

    // Database Actions
    suspend fun insertRule(rule: AutoReplyRule): Long = ruleDao.insertRule(rule)
    suspend fun updateRule(rule: AutoReplyRule) = ruleDao.updateRule(rule)
    suspend fun deleteRule(rule: AutoReplyRule) = ruleDao.deleteRule(rule)

    suspend fun insertProduct(product: Product): Long = productDao.insertProduct(product)
    suspend fun updateProduct(product: Product) = productDao.updateProduct(product)
    suspend fun deleteProduct(product: Product) = productDao.deleteProduct(product)

    suspend fun insertLead(lead: SalesLead): Long = leadDao.insertLead(lead)
    suspend fun clearLeads() = leadDao.clearAllLeads()

    // Order & Payment Actions
    suspend fun insertOrder(order: CustomerOrder): Long = orderDao.insertOrder(order)
    suspend fun updateOrderStatus(orderId: Long, status: String) = orderDao.updateOrderStatus(orderId, status)
    suspend fun deleteOrder(order: CustomerOrder) = orderDao.deleteOrder(order)
    suspend fun clearOrders() = orderDao.clearAllOrders()

    suspend fun insertBkashTransaction(tx: BkashTransaction): Long = bkashDao.insertTransaction(tx)

    // Core Matching Engine
    suspend fun processIncomingMessage(senderName: String, platform: String, messageText: String): String {
        val trimmed = messageText.trim().lowercase()
        val activeRules = ruleDao.getActiveRulesList()

        // 0. Smart Order & Payment Auto-Detection
        val isPaymentOrOrderIntent = trimmed.contains("bkash") || trimmed.contains("বিকাশ") ||
                trimmed.contains("nagad") || trimmed.contains("নগদ") ||
                trimmed.contains("rocket") || trimmed.contains("রকেট") ||
                trimmed.contains("trx") || trimmed.contains("trxid") ||
                trimmed.contains("অর্ডার") || trimmed.contains("order") ||
                trimmed.contains("ঠিকানা") || trimmed.contains("পেমেন্ট") ||
                trimmed.contains("টাকা") || trimmed.contains("দিছি") ||
                trimmed.contains("পাঠাইছি") || trimmed.contains("পাঠিয়েছি") ||
                trimmed.contains("কিনব") || trimmed.contains("চাই") ||
                trimmed.contains("01")

        if (isPaymentOrOrderIntent) {
            val phoneRegex = Regex("01[3-9][0-9\\s-]{8,11}")
            val phoneMatchRaw = phoneRegex.find(messageText)?.value
            val phoneMatch = phoneMatchRaw?.replace(Regex("[^0-9]"), "")?.let {
                if (it.length == 11) it else null
            } ?: "ফোন নম্বর সংগৃহীত হয়নি"

            val paymentMethod = when {
                trimmed.contains("nagad") || trimmed.contains("নগদ") -> "Nagad"
                trimmed.contains("rocket") || trimmed.contains("রকেট") -> "Rocket"
                trimmed.contains("bkash") || trimmed.contains("বিকাশ") -> "bKash"
                else -> "bKash"
            }

            val trxRegex = Regex("([A-Za-z0-9]{8,12})")
            val trxMatch = trxRegex.findAll(messageText)
                .map { it.value.uppercase() }
                .firstOrNull { candidate ->
                    candidate.length >= 8 &&
                            !candidate.startsWith("01") &&
                            !candidate.contains("HEADPHONES", ignoreCase = true) &&
                            !candidate.contains("SMART", ignoreCase = true)
                } ?: "N/A"

            val products = productDao.getAvailableProducts()
            val matchedProduct = products.firstOrNull { p ->
                trimmed.contains(p.code.lowercase()) ||
                        trimmed.contains(p.name.lowercase()) ||
                        p.name.lowercase().split(" ").any { word -> word.length > 3 && trimmed.contains(word) }
            } ?: products.firstOrNull()

            // Check if TrxID matches an actual received bKash / Nagad payment SMS in database
            val bkashTx = if (trxMatch != "N/A") bkashDao.getTransactionByTrxId(trxMatch) else null
            val isVerified = bkashTx != null

            val orderStatus = if (isVerified) CustomerOrder.STATUS_VERIFIED else CustomerOrder.STATUS_PENDING
            val generatedOrderId = "#ORD-${(1000..9999).random()}"

            val newOrder = CustomerOrder(
                orderId = generatedOrderId,
                customerName = senderName,
                customerPhone = phoneMatch,
                deliveryAddress = if (messageText.length > 15) messageText.take(120) else "মেসেজ হতে সংগৃহীত",
                productCode = matchedProduct?.code ?: "P101",
                productName = matchedProduct?.name ?: "General Product",
                totalPrice = matchedProduct?.price ?: 1850.0,
                paymentMethod = paymentMethod,
                trxId = trxMatch,
                status = orderStatus,
                platform = platform
            )

            orderDao.insertOrder(newOrder)
            if (isVerified && trxMatch != "N/A") {
                bkashDao.markClaimed(trxMatch)
            }

            val downloadUrl = matchedProduct?.buyUrl?.ifBlank { null }
                ?: "https://drive.google.com/drive/folders/digital_product_${matchedProduct?.code ?: "P101"}"

            val bKashNum = matchedProduct?.bkashNumber?.ifBlank { "01711223344" } ?: "01711223344"
            val nagadNum = matchedProduct?.nagadNumber?.ifBlank { "01899887766" } ?: "01899887766"
            val rocketNum = matchedProduct?.rocketNumber?.ifBlank { "01911223344" } ?: "01911223344"

            val reply = if (isVerified) {
                "✅ **পেমেন্ট ভেরিফাইড ও অর্ডার কনফার্মড!** 🎉\n\n" +
                        "ধন্যবাদ $senderName! আপনার ট্রানজেকশন ID ($trxMatch) টি আমাদের পেমেন্ট মেসেজের সাথে মিলিয়ে ভেরিফাই করা হয়েছে।\n\n" +
                        "📦 **অর্ডার আইডি:** $generatedOrderId\n" +
                        "🛒 **পণ্য:** ${newOrder.productName} (৳${newOrder.totalPrice})\n" +
                        "💳 **পেমেন্ট মাধ্যম:** $paymentMethod\n" +
                        "📲 **ফোন:** $phoneMatch\n\n" +
                        "📥 **আপনার কাঙ্ক্ষিত ডিজিটাল প্রোডাক্ট/ড্রাইভ ফাইল লিংক:**\n$downloadUrl\n\n" +
                        "📌 আপনার সমস্ত তথ্য কাস্টমার নোটে সেভ করা হয়েছে।"
            } else if (trxMatch != "N/A") {
                "⚠️ **পেমেন্ট তথ্য সংগৃহীত হয়েছে (যাচাইকরণের অপেক্ষায়)**\n\n" +
                        "ধন্যবাদ $senderName! আপনার TrxID: $trxMatch সিস্টেমে যুক্ত হয়েছে।\n\n" +
                        "📌 **পেমেন্ট ভেরিফিকেশন স্টেটাস:**\n" +
                        "আমাদের বিকাশ/নগদ ইনবক্সে আপনার TrxID টি ম্যাচ করা হচ্ছে। মেসেজ মিললেই এটি অটো-ভেরিফাই হয়ে যাবে এবং গুগল ড্রাইভ/ফাইল লিংক চলে আসবে!\n\n" +
                        "📦 **অর্ডার আইডি:** $generatedOrderId\n" +
                        "🛒 **পণ্য:** ${newOrder.productName} (৳${newOrder.totalPrice})\n" +
                        "📲 **কাস্টমার ফোন:** $phoneMatch\n\n" +
                        "📌 আপনার বিবরণ অর্ডার নোটসে সেভ করা হয়েছে।"
            } else {
                "✅ **অর্ডার তথ্য তৈরি হয়েছে**\n\n" +
                        "ধন্যবাদ $senderName! পণ্য: ${newOrder.productName} (৳${newOrder.totalPrice})\n\n" +
                        "💳 **পেমেন্ট সেন্ড-মানি নাম্বারসমূহ:**\n" +
                        "• 🌸 বিকাশ (bKash): $bKashNum\n" +
                        "• 🟠 নগদ (Nagad): $nagadNum\n" +
                        "• 🚀 রকেট (Rocket): $rocketNum\n\n" +
                        "টাকা পাঠানোর পর প্রাপ্ত TrxID টি আমাদের লিখে মেসেজ দিন। TrxID মিললেই সাথে সাথে ড্রাইভ লিংক পেয়ে যাবেন!"
            }

            leadDao.insertLead(SalesLead(
                senderName = senderName,
                platform = platform,
                incomingMessage = messageText,
                botReply = reply,
                status = if (isVerified) "PAYMENT_VERIFIED" else "ORDER_CREATED",
                matchedKeyword = generatedOrderId
            ))
            return reply
        }

        // 1. Try exact match first
        for (rule in activeRules) {
            if (rule.matchType == AutoReplyRule.MATCH_EXACT && trimmed == rule.keyword.lowercase()) {
                ruleDao.incrementUsage(rule.id)
                val reply = rule.response
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = reply,
                    status = "AUTO_REPLIED",
                    matchedKeyword = rule.keyword
                ))
                return reply
            }
        }

        // 2. Try contains match
        for (rule in activeRules) {
            if (rule.matchType == AutoReplyRule.MATCH_CONTAINS && trimmed.contains(rule.keyword.lowercase())) {
                ruleDao.incrementUsage(rule.id)
                val reply = rule.response
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = reply,
                    status = "AUTO_REPLIED",
                    matchedKeyword = rule.keyword
                ))
                return reply
            }
        }

        // 3. Try Product match by code or name
        val products = productDao.getAvailableProducts()
        for (product in products) {
            if (trimmed.contains(product.code.lowercase()) || trimmed.contains(product.name.lowercase())) {
                val reply = "পণ্য: ${product.name}\nমূল্য: ৳${product.price}\nবিবরণ: ${product.description}\nঅর্ডার লিংক: ${product.buyUrl.ifBlank { "মেসেজে আপনার ঠিকানা দিন" }}"
                leadDao.insertLead(SalesLead(
                    senderName = senderName,
                    platform = platform,
                    incomingMessage = messageText,
                    botReply = reply,
                    status = "PRODUCT_MATCH",
                    matchedKeyword = product.code
                ))
                return reply
            }
        }

        // 4. Multi-Provider AI Fallback if enabled
        if (isAiEnabled) {
            val productContext = products.joinToString("\n") { p ->
                "- ${p.name} (Code: ${p.code}): ৳${p.price}. ${p.description}"
            }

            val currentProvider = aiProvider
            val (activeApiKey, activeModel) = when (currentProvider) {
                "Groq" -> Pair(groqApiKey.ifBlank { customApiKey }, groqModel.ifBlank { "llama-3.1-8b-instant" })
                "ChatGPT" -> Pair(chatgptApiKey.ifBlank { customApiKey }, chatgptModel.ifBlank { "gpt-4o-mini" })
                else -> Pair(geminiApiKey.ifBlank { customApiKey }, geminiModel.ifBlank { "gemini-3.1-flash-lite" })
            }

            val aiReply = AiClient.generateSalesReply(
                provider = currentProvider,
                modelName = activeModel,
                apiKeyOverride = activeApiKey,
                customerMessage = messageText,
                productCatalogContext = productContext,
                customPrompt = customPrompt
            )
            leadDao.insertLead(SalesLead(
                senderName = senderName,
                platform = platform,
                incomingMessage = messageText,
                botReply = aiReply,
                status = "AI_REPLIED",
                matchedKeyword = "$currentProvider ($activeModel)"
            ))
            return aiReply
        }

        // Default fallback response
        val fallbackReply = "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি শীঘ্রই উত্তর দেবে।"
        leadDao.insertLead(SalesLead(
            senderName = senderName,
            platform = platform,
            incomingMessage = messageText,
            botReply = fallbackReply,
            status = "DEFAULT_REPLIED",
            matchedKeyword = "None"
        ))
        return fallbackReply
    }
}
