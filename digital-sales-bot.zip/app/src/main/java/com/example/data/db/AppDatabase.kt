package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [AutoReplyRule::class, Product::class, SalesLead::class, CustomerOrder::class, BkashTransaction::class],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun autoReplyRuleDao(): AutoReplyRuleDao
    abstract fun productDao(): ProductDao
    abstract fun salesLeadDao(): SalesLeadDao
    abstract fun customerOrderDao(): CustomerOrderDao
    abstract fun bkashTransactionDao(): BkashTransactionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "digital_sales_bot.db"
                )
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        INSTANCE?.let { database ->
                            CoroutineScope(Dispatchers.IO).launch {
                                populateInitialData(database)
                            }
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun populateInitialData(db: AppDatabase) {
            val defaultRules = listOf(
                AutoReplyRule(
                    keyword = "দাম কত",
                    response = "ধন্যবাদ আমাদের সাথে যোগাযোগের জন্য! আমাদের সেরা প্রোডাক্ট সমূহের তালিকা দেখতে প্রোডাক্ট সেকশন ভিজিট করুন। অথবা কোনো নির্দিষ্ট পণ্যের নাম লিখে মেসেজ দিন।",
                    matchType = AutoReplyRule.MATCH_CONTAINS,
                    category = "Pricing"
                ),
                AutoReplyRule(
                    keyword = "price",
                    response = "Hi! Thank you for contacting Digital Sales Bot. Please let us know which product you are interested in or check out our product catalog!",
                    matchType = AutoReplyRule.MATCH_CONTAINS,
                    category = "Pricing"
                ),
                AutoReplyRule(
                    keyword = "অর্ডার করব",
                    response = "অর্ডার করার জন্য অনুগ্রহ করে আপনার নাম, ঠিকানা এবং ফোন নম্বর লিখে পাঠান। আমরা দ্রুততম সময়ে আপনার সাথে যোগাযোগ করব!",
                    matchType = AutoReplyRule.MATCH_CONTAINS,
                    category = "Order"
                ),
                AutoReplyRule(
                    keyword = "delivery",
                    response = "আমরা সারা বাংলাদেশে ক্যাশ অন ডেলিভারিতে হোম ডেলিভারি দিয়ে থাকি। ডেলিভারি চার্জ ঢাকার মধ্যে ৬০ টাকা, ঢাকার বাইরে ১২০ টাকা।",
                    matchType = AutoReplyRule.MATCH_CONTAINS,
                    category = "Shipping"
                ),
                AutoReplyRule(
                    keyword = "হ্যালো",
                    response = "হ্যালো! Digital Sales Bot এ আপনাকে স্বাগতম 😊 কিভাবে আপনাকে সাহায্য করতে পারি?",
                    matchType = AutoReplyRule.MATCH_CONTAINS,
                    category = "Greeting"
                ),
                AutoReplyRule(
                    keyword = "hi",
                    response = "Hello! Welcome to Digital Sales Bot. How can we help you today?",
                    matchType = AutoReplyRule.MATCH_CONTAINS,
                    category = "Greeting"
                )
            )

            val defaultProducts = listOf(
                Product(
                    code = "P101",
                    name = "Smart Wireless Headphones",
                    price = 1850.0,
                    description = "High fidelity sound, active noise cancellation, 30 hours battery backup.",
                    stock = 15,
                    category = "Electronics",
                    buyUrl = "https://drive.google.com/drive/folders/sample_headphones_manual",
                    imageUrl = "https://picsum.photos/seed/headphones/300/300",
                    bkashNumber = "01711223344",
                    nagadNumber = "01899887766",
                    rocketNumber = "01911223344",
                    dbblNumber = "01611223344"
                ),
                Product(
                    code = "P102",
                    name = "Premium Sales CRM Software",
                    price = 4999.0,
                    description = "Automate your Facebook & WhatsApp business sales leads with AI power.",
                    stock = 99,
                    category = "Software",
                    buyUrl = "https://drive.google.com/drive/folders/sample_crm_software_download",
                    imageUrl = "https://picsum.photos/seed/software/300/300",
                    bkashNumber = "01711223344",
                    nagadNumber = "01899887766",
                    rocketNumber = "01911223344",
                    dbblNumber = "01611223344"
                ),
                Product(
                    code = "P103",
                    name = "Smart Fitness Watch",
                    price = 2490.0,
                    description = "Heart rate monitor, step tracking, OLED display, IP68 water resistant.",
                    stock = 8,
                    category = "Wearables",
                    buyUrl = "https://drive.google.com/drive/folders/sample_smartwatch_guide",
                    imageUrl = "https://picsum.photos/seed/watch/300/300",
                    bkashNumber = "01711223344",
                    nagadNumber = "01899887766",
                    rocketNumber = "01911223344",
                    dbblNumber = "01611223344"
                )
            )

            db.autoReplyRuleDao().insertRules(defaultRules)
            db.productDao().insertProducts(defaultProducts)
        }
    }
}
