package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val price: Double,
    val description: String,
    val stock: Int = 10,
    val category: String = "General",
    val buyUrl: String = "", // Digital product Google Drive link or download link
    val imageUrl: String = "", // Product photo URL or image link
    val bkashNumber: String = "", // bKash Personal/Merchant send-money number
    val nagadNumber: String = "", // Nagad send-money number
    val rocketNumber: String = "", // Rocket send-money number
    val dbblNumber: String = "", // Dutch-Bangla / CellFin payment account number
    val isAvailable: Boolean = true
)

