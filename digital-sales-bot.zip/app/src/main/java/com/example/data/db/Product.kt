package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val price: Double,
    val description: String,
    val stock: Int = 10,
    val category: String = "General",
    val buyUrl: String = "",
    val isAvailable: Boolean = true
)
