package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val price: Double,
    val description: String,
    val stock: Int = 10,
    val category: String = "General",
    val buyUrl: String = "", // Digital product Google Drive link or download link
    val imageUrl: String = "", // Product photo URL or image link
    val bkashNumber: String = "01711223344", // bKash Personal/Merchant send-money number
    val nagadNumber: String = "01899887766", // Nagad send-money number
    val rocketNumber: String = "01911223344", // Rocket send-money number
    val dbblNumber: String = "01611223344", // Dutch-Bangla / CellFin payment account number
    val isAvailable: Boolean = true
)

