package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "auto_reply_rules")
data class AutoReplyRule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val keyword: String,
    val response: String,
    val matchType: String = MATCH_CONTAINS, // EXACT, CONTAINS, AI_FALLBACK
    val category: String = "Sales",
    val isEnabled: Boolean = true,
    val usageCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val MATCH_EXACT = "EXACT"
        const val MATCH_CONTAINS = "CONTAINS"
        const val MATCH_AI = "AI_FALLBACK"
    }
}
