package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent? = null
)

// OpenAI & Groq API Data Classes
@JsonClass(generateAdapter = true)
data class OpenAiChatRequest(
    val model: String,
    val messages: List<OpenAiChatMessage>
)

@JsonClass(generateAdapter = true)
data class OpenAiChatMessage(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class OpenAiChatResponse(
    val choices: List<OpenAiChoice>? = null
)

@JsonClass(generateAdapter = true)
data class OpenAiChoice(
    val message: OpenAiChatMessage? = null
)

interface GeminiDynamicApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

interface OpenAiApiService {
    @POST("v1/chat/completions")
    suspend fun createChatCompletion(
        @Header("Authorization") authHeader: String,
        @Body request: OpenAiChatRequest
    ): OpenAiChatResponse
}

object AiClient {
    private const val GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/"
    private const val GROQ_BASE_URL = "https://api.groq.com/openai/"
    private const val OPENAI_BASE_URL = "https://api.openai.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshiFactory = MoshiConverterFactory.create()

    private val geminiApi: GeminiDynamicApiService by lazy {
        Retrofit.Builder()
            .baseUrl(GEMINI_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(GeminiDynamicApiService::class.java)
    }

    private val groqApi: OpenAiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(GROQ_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(OpenAiApiService::class.java)
    }

    private val openAiApi: OpenAiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(OPENAI_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(OpenAiApiService::class.java)
    }

    suspend fun generateSalesReply(
        provider: String,
        modelName: String,
        apiKeyOverride: String,
        customerMessage: String,
        productCatalogContext: String,
        customPrompt: String
    ): String {
        val systemPromptText = """
            You are a polite, professional, and friendly Digital Sales Bot assistant for an e-commerce store in Bangladesh.
            Respond concisely in Bengali or English (matching the user's language).
            
            Product Catalog Information:
            $productCatalogContext
            
            Bot Instructions:
            $customPrompt
            
            Give direct, helpful answers regarding product prices, specs, and ordering procedures. Keep replies short for chat messaging (under 3 sentences).
        """.trimIndent()

        return try {
            when (provider) {
                "Groq" -> {
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank()) {
                        return "ধন্যবাদ! Groq API ব্যবহার করতে Settings থেকে আপনার Groq API Key যুক্ত করুন।"
                    }
                    val selectedModel = modelName.ifBlank { "llama-3.1-8b-instant" }
                    val request = OpenAiChatRequest(
                        model = selectedModel,
                        messages = listOf(
                            OpenAiChatMessage(role = "system", content = systemPromptText),
                            OpenAiChatMessage(role = "user", content = customerMessage)
                        )
                    )
                    val response = groqApi.createChatCompletion(authHeader = "Bearer $key", request = request)
                    response.choices?.firstOrNull()?.message?.content
                        ?: "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই যোগাযোগ করবে।"
                }
                "ChatGPT" -> {
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank()) {
                        return "ধন্যবাদ! ChatGPT API ব্যবহার করতে Settings থেকে আপনার OpenAI API Key যুক্ত করুন।"
                    }
                    val selectedModel = modelName.ifBlank { "gpt-4o-mini" }
                    val request = OpenAiChatRequest(
                        model = selectedModel,
                        messages = listOf(
                            OpenAiChatMessage(role = "system", content = systemPromptText),
                            OpenAiChatMessage(role = "user", content = customerMessage)
                        )
                    )
                    val response = openAiApi.createChatCompletion(authHeader = "Bearer $key", request = request)
                    response.choices?.firstOrNull()?.message?.content
                        ?: "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই যোগাযোগ করবে।"
                }
                else -> { // Gemini
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
                        return "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই উত্তর দিবে।"
                    }
                    val selectedModel = modelName.ifBlank { "gemini-3.1-flash-lite" }
                    val request = GeminiRequest(
                        contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = customerMessage)))),
                        systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPromptText)))
                    )
                    val response = geminiApi.generateContent(model = selectedModel, apiKey = key, request = request)
                    response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        ?: "ধন্যবাদ আপনার আগ্রহের জন্য! অনুগ্রহ করে আপনার অর্ডার বিবরণ জানান।"
                }
            }
        } catch (e: Exception) {
            "ধন্যবাদ আপনার বার্তার জন্য! আমাদের সেলস টিম দ্রুত যোগাযোগ করবে।"
        }
    }
}

// Backward compatibility bridge for GeminiClient
object GeminiClient {
    suspend fun generateSalesReply(
        customerMessage: String,
        productCatalogContext: String,
        customPrompt: String,
        apiKeyOverride: String = ""
    ): String {
        return AiClient.generateSalesReply(
            provider = "Gemini",
            modelName = "gemini-3.1-flash-lite",
            apiKeyOverride = apiKeyOverride,
            customerMessage = customerMessage,
            productCatalogContext = productCatalogContext,
            customPrompt = customPrompt
        )
    }
}
