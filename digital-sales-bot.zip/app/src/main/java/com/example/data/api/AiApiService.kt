package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent? = null
)

// OpenAI & Groq API Data Classes
@JsonClass(generateAdapter = true)
data class OpenAiChatRequest(
    val model: String,
    val messages: List<OpenAiChatMessage>
)

@JsonClass(generateAdapter = true)
data class OpenAiChatMessage(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class OpenAiChatResponse(
    val choices: List<OpenAiChoice>? = null
)

@JsonClass(generateAdapter = true)
data class OpenAiChoice(
    val message: OpenAiChatMessage? = null
)

interface GeminiDynamicApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

interface OpenAiApiService {
    @POST("v1/chat/completions")
    suspend fun createChatCompletion(
        @Header("Authorization") authHeader: String,
        @Body request: OpenAiChatRequest
    ): OpenAiChatResponse
}

object AiClient {
    private const val GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/"
    private const val GROQ_BASE_URL = "https://api.groq.com/openai/"
    private const val OPENAI_BASE_URL = "https://api.openai.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshiFactory = MoshiConverterFactory.create()

    private val geminiApi: GeminiDynamicApiService by lazy {
        Retrofit.Builder()
            .baseUrl(GEMINI_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(GeminiDynamicApiService::class.java)
    }

    private val groqApi: OpenAiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(GROQ_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(OpenAiApiService::class.java)
    }

    private val openAiApi: OpenAiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(OPENAI_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(OpenAiApiService::class.java)
    }

    suspend fun generateSalesReply(
        provider: String,
        modelName: String,
        apiKeyOverride: String,
        customerName: String = "কাস্টমার",
        platform: String = "Messenger",
        isReturningCustomer: Boolean = false,
        customerMessage: String,
        productCatalogContext: String,
        paymentMethodsContext: String = "",
        chatHistoryContext: String = "",
        ordersHistoryContext: String = "",
        customPrompt: String
    ): String {
        val systemPromptText = """
            You are a polite, professional, and highly intelligent Digital Sales Bot assistant for an e-commerce store in Bangladesh.
            Respond concisely in Bengali or English (matching the user's language).
            
            ==================================================
            CUSTOMER IDENTIFICATION & CONTEXT:
            • Customer Name / ID: "$customerName"
            • Messaging Platform: $platform
            • Customer Status: ${if (isReturningCustomer) "RETURNING CUSTOMER (You have talked with this customer before!)" else "NEW CUSTOMER (First interaction)"}
            
            $chatHistoryContext
            
            $ordersHistoryContext
            ==================================================
            
            ==================================================
            PRIMARY USER DIRECTIVE / CUSTOM INSTRUCTIONS (MUST OBEY STRICTLY):
            $customPrompt
            ==================================================
            
            Product Catalog Information:
            $productCatalogContext
            
            $paymentMethodsContext
            
            CRITICAL MANDATES & COMPLIANCE RULES:
            1. RECOGNIZE & ADDRESS THE CUSTOMER: Always recognize who you are talking to ($customerName). Address them naturally by their name when appropriate.
            2. MULTI-PRODUCT SELECTION LOGIC:
               - If the store has MORE THAN 1 product available and $customerName HAS NOT specified which product they want yet (e.g., they just greeted or asked generally about buying/prices):
                 --> Show/list the available products concisely with prices (e.g., "আমাদের বর্তমানে ১. [Product 1] - ৳[Price], ২. [Product 2] - ৳[Price] ইত্যাদি প্রোডাক্ট আছে। আপনি কোনটি নিতে চাচ্ছেন?") and ask which one they are interested in!
               - Once $customerName chooses or mentions a specific product (or has already specified one in previous chat messages):
                 --> Focus specifically on that chosen product for details, features, price, marketing, and payment instructions.
            3. PREVENT REPETITIVE / CONFUSING QUESTIONS: Review the PREVIOUS CHAT HISTORY and ORDERS HISTORY above carefully. If $customerName already provided details (like phone number, address, or payment info) or previously selected a product, REMEMBER IT! Never ask repetitive or conflicting questions.
            4. ADAPT FOR RETURNING CUSTOMERS: If $customerName is a RETURNING CUSTOMER, welcome them back warmly (e.g., "হ্যালো $customerName ভাই/আপু, আবারো স্বাগতম! কীভাবে সাহায্য করতে পারি?") and continue the conversation seamlessly from where it left off.
            5. STRICT INSTRUCTION COMPLIANCE: You MUST strictly follow and obey all instructions provided in the "PRIMARY USER DIRECTIVE / CUSTOM INSTRUCTIONS" above.
            6. NO FAKE / GENERATED NUMBERS: NEVER invent, generate, guess, or output any default phone numbers, bKash, Nagad, or Rocket account numbers. ONLY use official enabled numbers.
            7. ACCURATE PRICING & PRODUCTS: Only give information about existing products in the catalog. Do not invent non-existent products or prices.
            8. CONCISE CHAT RESPONSES: Keep your responses polite, short (under 3-4 sentences), and natural for chat platforms.
        """.trimIndent()

        return try {
            when (provider) {
                "Groq" -> {
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank()) {
                        return "ধন্যবাদ! Groq API ব্যবহার করতে Settings থেকে আপনার Groq API Key যুক্ত করুন।"
                    }
                    val selectedModel = modelName.ifBlank { "llama-3.1-8b-instant" }
                    val request = OpenAiChatRequest(
                        model = selectedModel,
                        messages = listOf(
                            OpenAiChatMessage(role = "system", content = systemPromptText),
                            OpenAiChatMessage(role = "user", content = customerMessage)
                        )
                    )
                    val response = groqApi.createChatCompletion(authHeader = "Bearer $key", request = request)
                    response.choices?.firstOrNull()?.message?.content
                        ?: "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই যোগাযোগ করবে।"
                }
                "ChatGPT" -> {
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank()) {
                        return "ধন্যবাদ! ChatGPT API ব্যবহার করতে Settings থেকে আপনার OpenAI API Key যুক্ত করুন।"
                    }
                    val selectedModel = modelName.ifBlank { "gpt-4o-mini" }
                    val request = OpenAiChatRequest(
                        model = selectedModel,
                        messages = listOf(
                            OpenAiChatMessage(role = "system", content = systemPromptText),
                            OpenAiChatMessage(role = "user", content = customerMessage)
                        )
                    )
                    val response = openAiApi.createChatCompletion(authHeader = "Bearer $key", request = request)
                    response.choices?.firstOrNull()?.message?.content
                        ?: "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই যোগাযোগ করবে।"
                }
                else -> { // Gemini
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
                        return "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই উত্তর দিবে।"
                    }
                    val selectedModel = modelName.ifBlank { "gemini-3.1-flash-lite" }
                    val request = GeminiRequest(
                        contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = customerMessage)))),
                        systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPromptText)))
                    )
                    val response = geminiApi.generateContent(model = selectedModel, apiKey = key, request = request)
                    response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        ?: "ধন্যবাদ আপনার আগ্রহের জন্য! অনুগ্রহ করে আপনার অর্ডার বিবরণ জানান।"
                }
            }
        } catch (e: Exception) {
            "ধন্যবাদ আপনার বার্তার জন্য! আমাদের সেলস টিম দ্রুত যোগাযোগ করবে।"
        }
    }
}

// Backward compatibility bridge for GeminiClient
object GeminiClient {
    suspend fun generateSalesReply(
        customerMessage: String,
        productCatalogContext: String,
        customPrompt: String,
        apiKeyOverride: String = ""
    ): String {
        return AiClient.generateSalesReply(
            provider = "Gemini",
            modelName = "gemini-3.1-flash-lite",
            apiKeyOverride = apiKeyOverride,
            customerMessage = customerMessage,
            productCatalogContext = productCatalogContext,
            customPrompt = customPrompt
        )
    }
}
