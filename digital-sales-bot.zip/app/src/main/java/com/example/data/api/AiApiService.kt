package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent? = null
)

// OpenAI & Groq API Data Classes
@JsonClass(generateAdapter = true)
data class OpenAiChatRequest(
    val model: String,
    val messages: List<OpenAiChatMessage>
)

@JsonClass(generateAdapter = true)
data class OpenAiChatMessage(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class OpenAiChatResponse(
    val choices: List<OpenAiChoice>? = null
)

@JsonClass(generateAdapter = true)
data class OpenAiChoice(
    val message: OpenAiChatMessage? = null
)

interface GeminiDynamicApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

interface OpenAiApiService {
    @POST("v1/chat/completions")
    suspend fun createChatCompletion(
        @Header("Authorization") authHeader: String,
        @Body request: OpenAiChatRequest
    ): OpenAiChatResponse
}

object AiClient {
    private const val GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/"
    private const val GROQ_BASE_URL = "https://api.groq.com/openai/"
    private const val OPENAI_BASE_URL = "https://api.openai.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshiFactory = MoshiConverterFactory.create()

    private val geminiApi: GeminiDynamicApiService by lazy {
        Retrofit.Builder()
            .baseUrl(GEMINI_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(GeminiDynamicApiService::class.java)
    }

    private val groqApi: OpenAiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(GROQ_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(OpenAiApiService::class.java)
    }

    private val openAiApi: OpenAiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(OPENAI_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(moshiFactory)
            .build()
            .create(OpenAiApiService::class.java)
    }

    suspend fun generateSalesReply(
        provider: String,
        modelName: String,
        apiKeyOverride: String,
        customerName: String = "কাস্টমার",
        platform: String = "Messenger",
        isReturningCustomer: Boolean = false,
        customerMessage: String,
        productCatalogContext: String,
        paymentMethodsContext: String = "",
        chatHistoryContext: String = "",
        ordersHistoryContext: String = "",
        customPrompt: String
    ): String {
        val systemPromptText = """
            You are a polite, professional, and highly intelligent Digital Sales Bot assistant for an e-commerce store in Bangladesh.
            Respond concisely in Bengali or English (matching the user's language).
            
            ==================================================
            CUSTOMER IDENTIFICATION & CONTEXT:
            • Customer Name / ID: "$customerName"
            • Messaging Platform: $platform
            • Customer Status: ${if (isReturningCustomer) "RETURNING CUSTOMER (You have talked with this customer before!)" else "NEW CUSTOMER (First interaction)"}
            
            $chatHistoryContext
            
            $ordersHistoryContext
            ==================================================
            
            ==================================================
            PRIMARY USER DIRECTIVE / CUSTOM INSTRUCTIONS (MUST OBEY STRICTLY):
            $customPrompt
            ==================================================
            
            Product Catalog Information:
            $productCatalogContext
            
            $paymentMethodsContext
            
            CRITICAL MANDATES & COMPLIANCE RULES:
            1. RESPECTFUL SALUTATION (স্যার / ম্যাডাম MANDATE):
               - STRICT RULE: NEVER address or call the customer by their personal name ($customerName). Calling customers by name is strictly forbidden and considered impolite/disrespectful (বেয়াদব).
               - ALWAYS address the customer respectfully using "স্যার" (Sir) or "ম্যাডাম" (Madam) or polite Bengali honorifics (e.g. "হ্যালো স্যার", "জি স্যার/ম্যাডাম", "আপনাকে কীভাবে সাহায্য করতে পারি স্যার?").

            2. PERSUASIVE SALES & CONVERSION (পটিয়ে সেলস জেনারেট করা ও অর্ডার উৎসাহিত করা):
               - Do NOT just give passive information. Actively present key product features, value, and benefits to persuade the customer, build interest, and encourage them to place an order ("আকর্ষণীয়ভাবে প্রোডাক্ট উপস্থাপন করে সেলস জেনারেট করুন এবং অর্ডার করতে উৎসাহিত করুন").

            3. PAYMENT INSTRUCTIONS WITH "SEND MONEY" (সেন মানি করার স্পষ্ট নির্দেশ):
               - When a customer wants to order or asks how to pay, provide the official enabled bKash/Nagad/Rocket numbers from the settings above.
               - Explicitly instruct them to perform a "Send Money" (সেন মানি) to that number for the order amount (e.g., "অর্ডারটি কনফার্ম করতে আমাদের বিকাশ/নগদ [Number] নম্বরে ৳[Price] টাকা 'সেন মানি' (Send Money) করার জন্য অনুরোধ করছি, স্যার।").

            4. REQUEST TRANSACTION ID & DELIVERY DETAILS (ট্রানজেকশন কোড ও তথ্য চাওয়া):
               - Immediately after giving payment instructions, ask the customer to reply with:
                 ① The payment sender mobile number (টাকা পাঠানোর বিকাশ/নগদ নম্বর)
                 ② The Transaction ID / TrxID (ট্রানজেকশন কোড/আইডি)
                 ③ Full Delivery Address & Contact Phone Number (ডেলিভারি ঠিকানা ও মোবাইল নম্বর)

            5. SHORT, ELEGANT & DIRECT RESPONSES (কোনো বাড়তী কথা নয়, শর্টকাট টু-দ্য-পয়েন্ট উত্তর):
               - Avoid long ramblings or boilerplate fluff. Answer questions directly, politely, smartly, concisely (1-3 clear sentences), and persuasively.

            6. PREVENT REPETITIVE QUESTIONS: Check PREVIOUS CHAT HISTORY carefully. If details were already provided by the customer, remember them!
            7. NO FAKE NUMBERS OR PRODUCTS: Only use official configured payment numbers and real products in catalog. Do not invent fake numbers or imaginary products.
        """.trimIndent()

        return try {
            when (provider) {
                "Groq" -> {
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank()) {
                        return "ধন্যবাদ! Groq API ব্যবহার করতে Settings থেকে আপনার Groq API Key যুক্ত করুন।"
                    }
                    val selectedModel = modelName.ifBlank { "llama-3.1-8b-instant" }
                    val request = OpenAiChatRequest(
                        model = selectedModel,
                        messages = listOf(
                            OpenAiChatMessage(role = "system", content = systemPromptText),
                            OpenAiChatMessage(role = "user", content = customerMessage)
                        )
                    )
                    val response = groqApi.createChatCompletion(authHeader = "Bearer $key", request = request)
                    response.choices?.firstOrNull()?.message?.content
                        ?: "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই যোগাযোগ করবে।"
                }
                "ChatGPT" -> {
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank()) {
                        return "ধন্যবাদ! ChatGPT API ব্যবহার করতে Settings থেকে আপনার OpenAI API Key যুক্ত করুন।"
                    }
                    val selectedModel = modelName.ifBlank { "gpt-4o-mini" }
                    val request = OpenAiChatRequest(
                        model = selectedModel,
                        messages = listOf(
                            OpenAiChatMessage(role = "system", content = systemPromptText),
                            OpenAiChatMessage(role = "user", content = customerMessage)
                        )
                    )
                    val response = openAiApi.createChatCompletion(authHeader = "Bearer $key", request = request)
                    response.choices?.firstOrNull()?.message?.content
                        ?: "ধন্যবাদ আপনার বার্তার জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই যোগাযোগ করবে।"
                }
                else -> { // Gemini
                    val key = apiKeyOverride.ifBlank { BuildConfig.GEMINI_API_KEY }
                    if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
                        return "ধন্যবাদ! Gemini AI ব্যবহার করার জন্য সেটিংস অ্যাপ থেকে আপনার Gemini API Key সেভ করুন।"
                    }
                    val rawModel = modelName.ifBlank { "gemini-2.0-flash" }
                    val selectedModel = if (rawModel.contains("gemini-3.1")) "gemini-2.0-flash" else rawModel

                    val userPromptText = if (customPrompt.isNotBlank()) {
                        "📌 [CRITICAL BOT DIRECTIVE / নির্দেশিকা: $customPrompt]\n\n💬 Customer Message: $customerMessage"
                    } else {
                        customerMessage
                    }

                    val request = GeminiRequest(
                        contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = userPromptText)))),
                        systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPromptText)))
                    )
                    val response = geminiApi.generateContent(model = selectedModel, apiKey = key, request = request)
                    val generatedText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!generatedText.isNullOrBlank()) {
                        generatedText
                    } else {
                        "ধন্যবাদ আপনার মেসেজের জন্য! আমাদের প্রতিনিধি খুব শীঘ্রই উত্তর দিবেন।"
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("AiClient", "AI Generation Error: ${e.message}", e)
            "ধন্যবাদ আপনার বার্তার জন্য! আমাদের সেলস টিম দ্রুত যোগাযোগ করবে।"
        }
    }
}

// Backward compatibility bridge for GeminiClient
object GeminiClient {
    suspend fun generateSalesReply(
        customerMessage: String,
        productCatalogContext: String,
        customPrompt: String,
        apiKeyOverride: String = ""
    ): String {
        return AiClient.generateSalesReply(
            provider = "Gemini",
            modelName = "gemini-3.1-flash-lite",
            apiKeyOverride = apiKeyOverride,
            customerMessage = customerMessage,
            productCatalogContext = productCatalogContext,
            customPrompt = customPrompt
        )
    }
}
