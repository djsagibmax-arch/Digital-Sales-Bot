package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AutoReplyRuleDao {
    @Query("SELECT * FROM auto_reply_rules ORDER BY id DESC")
    fun getAllRules(): Flow<List<AutoReplyRule>>

    @Query("SELECT * FROM auto_reply_rules WHERE isEnabled = 1")
    suspend fun getActiveRulesList(): List<AutoReplyRule>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: AutoReplyRule): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRules(rules: List<AutoReplyRule>)

    @Update
    suspend fun updateRule(rule: AutoReplyRule)

    @Delete
    suspend fun deleteRule(rule: AutoReplyRule)

    @Query("UPDATE auto_reply_rules SET usageCount = usageCount + 1 WHERE id = :ruleId")
    suspend fun incrementUsage(ruleId: Long)

    @Query("DELETE FROM auto_reply_rules")
    suspend fun deleteAllRules()
}
