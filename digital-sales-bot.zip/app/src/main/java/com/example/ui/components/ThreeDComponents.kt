package com.example.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Vibrant 3D Color Palettes
object ThreeDColors {
    val PurplePrimary = listOf(Color(0xFF8B5CF6), Color(0xFF6D28D9))
    val PurpleBottom = Color(0xFF4C1D95)

    val BluePrimary = listOf(Color(0xFF3B82F6), Color(0xFF1D4ED8))
    val BlueBottom = Color(0xFF1E3A8A)

    val EmeraldGreen = listOf(Color(0xFF10B981), Color(0xFF047857))
    val GreenBottom = Color(0xFF065F46)

    val CoralOrange = listOf(Color(0xFFF97316), Color(0xFFC2410C))
    val OrangeBottom = Color(0xFF9A3412)

    val RosePink = listOf(Color(0xFFEC4899), Color(0xFFBE185D))
    val PinkBottom = Color(0xFF831843)

    val UnselectedChip = listOf(Color(0xFF334155), Color(0xFF1E293B))
    val UnselectedBottom = Color(0xFF0F172A)
}

@Composable
fun ThreeDButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    gradientColors: List<Color> = ThreeDColors.PurplePrimary,
    bottomColor: Color = ThreeDColors.PurpleBottom,
    contentColor: Color = Color.White,
    cornerRadius: Dp = 16.dp,
    bottomDepth: Dp = 5.dp,
    content: @Composable RowScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val offsetY by animateDpAsState(
        targetValue = if (isPressed) bottomDepth else 0.dp,
        label = "button_3d_press"
    )

    Box(
        modifier = modifier
            .padding(bottom = bottomDepth)
    ) {
        // 3D Bottom Depth Shadow
        Box(
            modifier = Modifier
                .matchParentSize()
                .offset(y = bottomDepth)
                .clip(RoundedCornerShape(cornerRadius))
                .background(if (enabled) bottomColor else Color.DarkGray)
        )

        // 3D Top Surface
        Box(
            modifier = Modifier
                .offset(y = offsetY)
                .clip(RoundedCornerShape(cornerRadius))
                .background(
                    brush = if (enabled) Brush.horizontalGradient(gradientColors)
                    else Brush.horizontalGradient(listOf(Color.Gray, Color.DarkGray))
                )
                .clickable(
                    enabled = enabled,
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick
                )
                .padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                CompositionLocalProvider(LocalContentColor provides contentColor) {
                    content()
                }
            }
        }
    }
}

@Composable
fun ThreeDChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    icon: (@Composable () -> Unit)? = null,
    selectedGradient: List<Color> = ThreeDColors.BluePrimary,
    selectedBottomColor: Color = ThreeDColors.BlueBottom,
    unselectedGradient: List<Color> = ThreeDColors.UnselectedChip,
    unselectedBottomColor: Color = ThreeDColors.UnselectedBottom
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val bottomDepth = 4.dp
    val offsetY by animateDpAsState(
        targetValue = if (isPressed) bottomDepth else 0.dp,
        label = "chip_3d_press"
    )

    Box(
        modifier = modifier.padding(bottom = bottomDepth, top = 2.dp, end = 6.dp)
    ) {
        // Bottom Depth Shadow Layer
        Box(
            modifier = Modifier
                .matchParentSize()
                .offset(y = bottomDepth)
                .clip(RoundedCornerShape(12.dp))
                .background(if (selected) selectedBottomColor else unselectedBottomColor)
        )

        // Top Interactive Surface
        Box(
            modifier = Modifier
                .offset(y = offsetY)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    brush = if (selected) Brush.horizontalGradient(selectedGradient)
                    else Brush.horizontalGradient(unselectedGradient)
                )
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick
                )
                .padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (icon != null) {
                    icon()
                }
                Text(
                    text = label,
                    color = if (selected) Color.White else Color(0xFFE2E8F0),
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 13.sp,
                    maxLines = 1
                )
            }
        }
    }
}
