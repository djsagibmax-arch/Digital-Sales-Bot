package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.SalesBotUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    state: SalesBotUiState,
    onToggleAi: (Boolean) -> Unit,
    onSetReplyDelay: (Int) -> Unit,
    onSaveAiSettings: (String, String) -> Unit,
    onTogglePlatform: (String, Boolean) -> Unit
) {
    val context = LocalContext.current
    var customPrompt by remember(state.customPrompt) { mutableStateOf(state.customPrompt) }
    var customApiKey by remember(state.customApiKey) { mutableStateOf(state.customApiKey) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "বট সেটিংস & কনফিগারেশন",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        // Android System Notification Permission Link
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("নোটিফিকেশন লিসেনার পারমিশন", fontWeight = FontWeight.Bold)
                        Text(
                            text = if (state.isNotificationAccessGranted) "পারমিশন সক্রিয় করা আছে" else "পারমিশন নিষ্ক্রিয় রয়েছে",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (state.isNotificationAccessGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                            context.startActivity(intent)
                        }
                    ) {
                        Text("সেটিংস খুলুন")
                    }
                }
            }
        }

        // Target Platforms Configuration
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("টার্গেট অ্যাপস (Target Platforms)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("যেসব মেসেজিং অ্যাপ থেকে নোটিফিকেশন আসলে বট অটো-রিপ্লাই দেবে:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)

                Spacer(modifier = Modifier.height(8.dp))

                PlatformToggleItem("WhatsApp", state.whatsappEnabled) { onTogglePlatform("WhatsApp", it) }
                PlatformToggleItem("Facebook Messenger", state.messengerEnabled) { onTogglePlatform("Messenger", it) }
                PlatformToggleItem("SMS Messaging", state.smsEnabled) { onTogglePlatform("SMS", it) }
                PlatformToggleItem("Telegram", state.telegramEnabled) { onTogglePlatform("Telegram", it) }
            }
        }

        // Delay & Bot Response Speed Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("রিপ্লাই বিলম্ব সময় (Response Delay)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("মেসেজ পাওয়ার কত সেকেন্ড পর উত্তর দেবে (স্বাভাবিক দেখানোর জন্য):", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 3, 5, 10).forEach { sec ->
                        FilterChip(
                            selected = state.replyDelaySeconds == sec,
                            onClick = { onSetReplyDelay(sec) },
                            label = { Text("$sec সেকেণ্ড") }
                        )
                    }
                }
            }
        }

        // Gemini AI Smart Fallback Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Gemini 3.5 AI অটো-রিপ্লাই", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("কীওয়ার্ড না মিললে AI নিজে উত্তর তৈরি করবে", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                    Switch(checked = state.isAiEnabled, onCheckedChange = onToggleAi)
                }

                if (state.isAiEnabled) {
                    OutlinedTextField(
                        value = customPrompt,
                        onValueChange = { customPrompt = it },
                        label = { Text("AI সেলস বটের নির্দেশিকা (System Prompt)") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = customApiKey,
                        onValueChange = { customApiKey = it },
                        label = { Text("Gemini API Key (ঐচ্ছিক)") },
                        singleLine = true,
                        placeholder = { Text("খালি রাখলে সিস্টেমের কী ব্যবহার হবে") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = { onSaveAiSettings(customPrompt, customApiKey) },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI সেটিংস সেভ করুন")
                    }
                }
            }
        }
    }
}

@Composable
fun PlatformToggleItem(
    name: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = enabled, onCheckedChange = onToggle)
    }
}
