package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.SalesBotUiState
import com.example.ui.components.ThreeDButton
import com.example.ui.components.ThreeDChip
import com.example.ui.components.ThreeDColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    state: SalesBotUiState,
    onToggleAi: (Boolean) -> Unit,
    onSetReplyDelay: (Int) -> Unit,
    onSaveAiConfig: (
        provider: String,
        prompt: String,
        geminiKey: String,
        geminiModel: String,
        groqKey: String,
        groqModel: String,
        chatgptKey: String,
        chatgptModel: String
    ) -> Unit,
    onTogglePlatform: (String, Boolean) -> Unit
) {
    val context = LocalContext.current

    var selectedProvider by remember { mutableStateOf(state.aiProvider) }
    var customPrompt by remember { mutableStateOf(state.customPrompt) }

    var geminiKey by remember { mutableStateOf(state.geminiApiKey) }
    var geminiModel by remember { mutableStateOf(state.geminiModel) }

    var groqKey by remember { mutableStateOf(state.groqApiKey) }
    var groqModel by remember { mutableStateOf(state.groqModel) }

    var chatgptKey by remember { mutableStateOf(state.chatgptApiKey) }
    var chatgptModel by remember { mutableStateOf(state.chatgptModel) }

    // Dynamic Permission Checks
    var isIgnoringBatteryOptimizations by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                pm.isIgnoringBatteryOptimizations(context.packageName)
            } else true
        )
    }

    var canDrawOverlays by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else true
        )
    }

    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "বট সেটিংস & পারমিশন কনফিগারেশন",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        // Screen-Off & Master Permission Center Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Security,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("📱 ২০/২৪ স্ক্রিন অফ ও ব্যাকগ্রাউন্ড পারমিশন সেন্টার", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("মোবাইল লক বা স্ক্রিন বন্ধ থাকলেও ১০০০% অটো-মেসেজ পাঠাতে নিচের পারমিশনগুলো অন করুন:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Divider()

                // Permission 1: Notification Listener (Shutter bar access)
                PermissionRowItem(
                    title = "১. নোটিফিকেশন লিসেনার (শাটার বার মেসেজ)",
                    description = "ম্যাসেঞ্জার, হোয়াটসঅ্যাপ ও এসএমএস নোটিফিকেশন থেকে মেসেজ পড়া ও সরাসরি রিপ্লাই পাঠাতে",
                    isGranted = state.isNotificationAccessGranted,
                    onGrantClick = {
                        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                        context.startActivity(intent)
                    }
                )

                // Permission 2: Battery Optimization Exemption (Screen Off execution)
                PermissionRowItem(
                    title = "২. ব্যাটারি সেভার অপটিমাইজেশন বন্ধ",
                    description = "ফোন লক হলে অ্যান্ড্রয়েড যাতে ব্যাকগ্রাউন্ড সার্ভিস কিল না করে ২৪ ঘণ্টা চাল রাখে",
                    isGranted = isIgnoringBatteryOptimizations,
                    onGrantClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            try {
                                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                context.startActivity(intent)
                            }
                        }
                    }
                )

                // Permission 3: System Notifications (Online Messages Alert)
                PermissionRowItem(
                    title = "৩. সিস্টেম নোটিফিকেশন পারমিশন",
                    description = "অনলাইন মেসেজিং অ্যাপস থেকে মেসেজ আসলে ব্যাকগ্রাউন্ডে মেসেজ প্রোসেস করতে",
                    isGranted = hasNotificationPermission,
                    onGrantClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                )

                // Permission 4: Draw over other apps / Overlay (Messenger fallback)
                PermissionRowItem(
                    title = "৪. অ্যাপসের উপর মেসেঞ্জার উইন্ডো খোলা (Overlay)",
                    description = "নোটিফিকেশন থেকে রিপ্লাই ব্যর্থ হলে সরাসরি মেসেঞ্জার অ্যাপ ওপেন করে প্রথম চ্যাটে অনলাইন মেসেজ পাঠাতে",
                    isGranted = canDrawOverlays,
                    onGrantClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    }
                )
            }
        }

        // Target Platforms Configuration
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("টার্গেট অ্যাপস (Target Platforms)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("যেসব মেসেজিং অ্যাপ থেকে নোটিফিকেশন আসলে বট অটো-রিপ্লাই দেবে:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)

                Spacer(modifier = Modifier.height(12.dp))

                PlatformToggleItem("WhatsApp", state.whatsappEnabled) { onTogglePlatform("WhatsApp", it) }
                PlatformToggleItem("Facebook Messenger", state.messengerEnabled) { onTogglePlatform("Messenger", it) }
                PlatformToggleItem("Online Messaging (Shutter Bar)", state.smsEnabled) { onTogglePlatform("SMS", it) }
                PlatformToggleItem("Telegram", state.telegramEnabled) { onTogglePlatform("Telegram", it) }
            }
        }

        // Delay & Bot Response Speed Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("রিপ্লাই বিলম্ব সময় (Response Delay)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("মেসেজ পাওয়ার কত সেকেন্ড পর উত্তর দেবে (স্বাভাবিক দেখানোর জন্য):", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 3, 5, 10).forEach { sec ->
                        ThreeDChip(
                            selected = state.replyDelaySeconds == sec,
                            onClick = { onSetReplyDelay(sec) },
                            label = "$sec সেকেণ্ড",
                            selectedGradient = ThreeDColors.EmeraldGreen,
                            selectedBottomColor = ThreeDColors.GreenBottom
                        )
                    }
                }
            }
        }

        // Multi-Provider AI Fallback Engine Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("মাস্টার AI অটো-রিপ্লাই", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("কীওয়ার্ড না মিললে AI মডেল ব্যবহার করে স্মার্ট রিপ্লাই জেনারেট করবে", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                    Switch(checked = state.isAiEnabled, onCheckedChange = onToggleAi)
                }

                if (state.isAiEnabled) {
                    Divider()

                    Text("সক্রিয় AI প্রোভাইডার সিলেক্ট করুন:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "Gemini" to "Google Gemini",
                            "Groq" to "Groq (Free Plan)",
                            "ChatGPT" to "ChatGPT / OpenAI"
                        ).forEach { (providerKey, providerTitle) ->
                            ThreeDChip(
                                selected = selectedProvider == providerKey,
                                onClick = { selectedProvider = providerKey },
                                label = providerTitle,
                                icon = if (selectedProvider == providerKey) {
                                    { Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                                } else null,
                                selectedGradient = when (providerKey) {
                                    "Groq" -> ThreeDColors.CoralOrange
                                    "ChatGPT" -> ThreeDColors.RosePink
                                    else -> ThreeDColors.PurplePrimary
                                },
                                selectedBottomColor = when (providerKey) {
                                    "Groq" -> ThreeDColors.OrangeBottom
                                    "ChatGPT" -> ThreeDColors.PinkBottom
                                    else -> ThreeDColors.PurpleBottom
                                }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = customPrompt,
                        onValueChange = { customPrompt = it },
                        label = { Text("AI সেলস বটের নির্দেশিকা (System Prompt)") },
                        placeholder = { Text("যেমন: কাস্টমারদের সাথে সদ্ব্যবহার করো এবং পণ্যের দাম বলো...") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Divider()

                    when (selectedProvider) {
                        "Gemini" -> {
                            Text("Gemini AI সেটিংস", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                            OutlinedTextField(
                                value = geminiKey,
                                onValueChange = { geminiKey = it },
                                label = { Text("Gemini API Key") },
                                singleLine = true,
                                placeholder = { Text("আপনার Gemini API Key লিখুন") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = geminiModel,
                                onValueChange = { geminiModel = it },
                                label = { Text("Gemini Model Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text("জনপ্রিয় মডেল সিলেক্ট করুন:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("gemini-3.1-flash-lite", "gemini-2.0-flash", "gemini-1.5-flash").forEach { model ->
                                    ThreeDChip(
                                        selected = geminiModel == model,
                                        onClick = { geminiModel = model },
                                        label = model,
                                        selectedGradient = ThreeDColors.BluePrimary,
                                        selectedBottomColor = ThreeDColors.BlueBottom
                                    )
                                }
                            }
                        }

                        "Groq" -> {
                            Text("Groq (Free Plan) AI সেটিংস", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                            OutlinedTextField(
                                value = groqKey,
                                onValueChange = { groqKey = it },
                                label = { Text("Groq API Key") },
                                singleLine = true,
                                placeholder = { Text("gsk_... দিয়ে শুরু Groq Key দিন") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = groqModel,
                                onValueChange = { groqModel = it },
                                label = { Text("Groq Model Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text("জনপ্রিয় ফ্রি মডেল সমূহ:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("llama-3.1-8b-instant", "llama-3.3-70b-versatile", "mixtral-8x7b-32768").forEach { model ->
                                    ThreeDChip(
                                        selected = groqModel == model,
                                        onClick = { groqModel = model },
                                        label = model,
                                        selectedGradient = ThreeDColors.CoralOrange,
                                        selectedBottomColor = ThreeDColors.OrangeBottom
                                    )
                                }
                            }
                        }

                        "ChatGPT" -> {
                            Text("ChatGPT / OpenAI AI সেটিংস", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                            OutlinedTextField(
                                value = chatgptKey,
                                onValueChange = { chatgptKey = it },
                                label = { Text("OpenAI / ChatGPT API Key") },
                                singleLine = true,
                                placeholder = { Text("sk-... দিয়ে শুরু OpenAI Key দিন") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = chatgptModel,
                                onValueChange = { chatgptModel = it },
                                label = { Text("ChatGPT Model Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text("জনপ্রিয় ChatGPT মডেল সমূহ:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("gpt-4o-mini", "gpt-4o", "GPT-5.x").forEach { model ->
                                    ThreeDChip(
                                        selected = chatgptModel == model,
                                        onClick = { chatgptModel = model },
                                        label = model,
                                        selectedGradient = ThreeDColors.RosePink,
                                        selectedBottomColor = ThreeDColors.PinkBottom
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    ThreeDButton(
                        onClick = {
                            onSaveAiConfig(
                                selectedProvider,
                                customPrompt,
                                geminiKey,
                                geminiModel,
                                groqKey,
                                groqModel,
                                chatgptKey,
                                chatgptModel
                            )
                            Toast.makeText(context, "$selectedProvider AI সেটিংস সফলভাবে সেভ হয়েছে!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        gradientColors = when (selectedProvider) {
                            "Groq" -> ThreeDColors.CoralOrange
                            "ChatGPT" -> ThreeDColors.RosePink
                            else -> ThreeDColors.PurplePrimary
                        },
                        bottomColor = when (selectedProvider) {
                            "Groq" -> ThreeDColors.OrangeBottom
                            "ChatGPT" -> ThreeDColors.PinkBottom
                            else -> ThreeDColors.PurpleBottom
                        }
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("$selectedProvider AI সেটিংস সেভ করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionRowItem(
    title: String,
    description: String,
    isGranted: Boolean,
    onGrantClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.width(6.dp))
                if (isGranted) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Active",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Icon(
                        Icons.Default.ErrorOutline,
                        contentDescription = "Missing",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.sp,
                color = if (isGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }

        ThreeDButton(
            onClick = onGrantClick,
            gradientColors = if (isGranted) ThreeDColors.EmeraldGreen else ThreeDColors.CoralOrange,
            bottomColor = if (isGranted) ThreeDColors.GreenBottom else ThreeDColors.OrangeBottom,
            cornerRadius = 12.dp,
            bottomDepth = 3.dp
        ) {
            Text(if (isGranted) "অন আছে" else "অন করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PlatformToggleItem(
    name: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        Switch(checked = enabled, onCheckedChange = onToggle)
    }
}
