package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.db.Product
import com.example.ui.SalesBotUiState
import com.example.ui.components.ThreeDButton
import com.example.ui.components.ThreeDColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductsScreen(
    state: SalesBotUiState,
    onAddProduct: (
        code: String,
        name: String,
        price: Double,
        description: String,
        stock: Int,
        category: String,
        buyUrl: String,
        imageUrl: String,
        bkash: String,
        nagad: String,
        rocket: String,
        dbbl: String,
        isAvailable: Boolean
    ) -> Unit,
    onUpdateProduct: (Product) -> Unit,
    onDeleteProduct: (Product) -> Unit
) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showPaymentGatewayInfo by remember { mutableStateOf(true) }

    Scaffold(
        floatingActionButton = {
            ThreeDButton(
                onClick = { showAddDialog = true },
                gradientColors = ThreeDColors.EmeraldGreen,
                bottomColor = ThreeDColors.GreenBottom,
                cornerRadius = 24.dp,
                bottomDepth = 5.dp
            ) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("নতুন পণ্য যোগ করুন", fontWeight = FontWeight.Bold)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "প্রোডাক্ট ক্যাটালগ ও পেমেন্ট নম্বর (${state.products.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "বট মার্কেটিং অন/অফ বাটন এবং ড্রাইভ/ফাইল পেমেন্ট লিংক সেটআপ",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            // Merchant Payment Numbers Overview Card (bKash, Nagad, Rocket)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Payments,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "পেমেন্ট গেটওয়ে একাউন্ট নম্বর (Send Money)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(onClick = { showPaymentGatewayInfo = !showPaymentGatewayInfo }) {
                                Icon(
                                    if (showPaymentGatewayInfo) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = "Toggle"
                                )
                            }
                        }

                        if (showPaymentGatewayInfo) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "কাস্টমার বিকাশ, নগদ বা রকেট সিলেক্ট করলে বট অটোমেটিক আপনার সেন্ড-মানি একাউন্ট নম্বর পাঠাবে এবং পেমেন্ট ভেরিফাই হলে গুগল ড্রাইভ / ফাইল লিংক প্রদান করবে:",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                PaymentChip(title = "bKash (বিকাশ)", color = Color(0xFFE2136E), icon = Icons.Default.AccountBalanceWallet)
                                PaymentChip(title = "Nagad (নগদ)", color = Color(0xFFF7931E), icon = Icons.Default.MonetizationOn)
                                PaymentChip(title = "Rocket (রকেট)", color = Color(0xFF8C3494), icon = Icons.Default.Send)
                            }
                        }
                    }
                }
            }

            if (state.products.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("কোনো প্রোডাক্ট নেই", fontWeight = FontWeight.Bold)
                            Text("পণ্য ও পেমেন্ট নম্বর যোগ করতে নিচের বাটনে চাপ দিন।")
                        }
                    }
                }
            } else {
                items(state.products, key = { it.id }) { product ->
                    ProductItemCard(
                        product = product,
                        onUpdateProduct = onUpdateProduct,
                        onEdit = { editingProduct = product },
                        onDelete = { onDeleteProduct(product) }
                    )
                }
            }
        }

        if (showAddDialog) {
            AddEditProductDialog(
                productToEdit = null,
                onDismiss = { showAddDialog = false },
                onConfirm = { code, name, price, desc, stock, category, buyUrl, imageUrl, bkash, nagad, rocket, dbbl, isAvailable ->
                    onAddProduct(code, name, price, desc, stock, category, buyUrl, imageUrl, bkash, nagad, rocket, dbbl, isAvailable)
                    showAddDialog = false
                    Toast.makeText(context, "প্রোডাক্ট সফলভাবে যুক্ত হয়েছে!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        editingProduct?.let { product ->
            AddEditProductDialog(
                productToEdit = product,
                onDismiss = { editingProduct = null },
                onConfirm = { code, name, price, desc, stock, category, buyUrl, imageUrl, bkash, nagad, rocket, dbbl, isAvailable ->
                    val updated = product.copy(
                        code = code,
                        name = name,
                        price = price,
                        description = desc,
                        stock = stock,
                        category = category,
                        buyUrl = buyUrl,
                        imageUrl = imageUrl,
                        bkashNumber = bkash,
                        nagadNumber = nagad,
                        rocketNumber = rocket,
                        dbblNumber = dbbl,
                        isAvailable = isAvailable
                    )
                    onUpdateProduct(updated)
                    editingProduct = null
                    Toast.makeText(context, "প্রোডাক্ট আপডেট হয়েছে!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun PaymentChip(title: String, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(title, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun ProductItemCard(
    product: Product,
    onUpdateProduct: (Product) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (product.isAvailable) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Bot Marketing Active Switch Header Bar
            Surface(
                color = if (product.isAvailable) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (product.isAvailable) Icons.Default.SmartToy else Icons.Default.PauseCircleOutline,
                            contentDescription = null,
                            tint = if (product.isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "🤖 বট মার্কেটিং সার্ভিস",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (product.isAvailable) "সক্রিয় (বট এই প্রোডাক্টটি কাস্টমারকে অফার করবে)" else "নিষ্ক্রিয় (বট এই প্রোডাক্ট মার্কেটিং করবে না)",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = if (product.isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Switch(
                        checked = product.isAvailable,
                        onCheckedChange = { isChecked ->
                            onUpdateProduct(product.copy(isAvailable = isChecked))
                            val msg = if (isChecked) "🤖 '${product.name}' মার্কেটিং চালু করা হয়েছে!" else "⏸️ '${product.name}' মার্কেটিং বন্ধ করা হয়েছে।"
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // Product Header: Image, Title, Code & Action Icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Product Photo Thumbnail
                    if (product.imageUrl.isNotBlank()) {
                        AsyncImage(
                            model = product.imageUrl,
                            contentDescription = product.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.ShoppingBag,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AssistChip(
                                onClick = {},
                                label = { Text("কোড: ${product.code}", fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = product.category,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }

                        Text(
                            text = product.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "মূল্য: ৳${product.price.toInt()}  •  স্টক: ${product.stock} টি",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (product.description.isNotBlank()) {
                Text(
                    text = product.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            Divider()

            Spacer(modifier = Modifier.height(8.dp))

            // Digital Link Deliverable Section
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.CloudDownload,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ডিজিটাল প্রোডাক্ট / ফাইল / গুগল ড্রাইভ লিংক:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (product.buyUrl.isNotBlank()) {
                        TextButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Drive Link", product.buyUrl)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "ড্রাইভ লিংক কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("কপি করুন", fontSize = 11.sp)
                        }
                    }
                }

                Text(
                    text = if (product.buyUrl.isNotBlank()) product.buyUrl else "কোনো ড্রাইভ/ফাইল লিংক যুক্ত করা হয়নি (যোগ করতে এডিটে চাপুন)।",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (product.buyUrl.isNotBlank()) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Merchant Payment Numbers Display (bKash, Nagad, Rocket)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(10.dp)
            ) {
                Text(
                    text = "💳 কাস্টমারকে পেমেন্টের জন্য পাঠানো একাউন্ট নম্বরসমূহ:",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("🌸 বিকাশ: ${product.bkashNumber}", style = MaterialTheme.typography.labelSmall)
                    Text("🟠 নগদ: ${product.nagadNumber}", style = MaterialTheme.typography.labelSmall)
                    Text("🚀 রকেট: ${product.rocketNumber}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditProductDialog(
    productToEdit: Product?,
    onDismiss: () -> Unit,
    onConfirm: (
        code: String,
        name: String,
        price: Double,
        desc: String,
        stock: Int,
        category: String,
        buyUrl: String,
        imageUrl: String,
        bkash: String,
        nagad: String,
        rocket: String,
        dbbl: String,
        isAvailable: Boolean
    ) -> Unit
) {
    val context = LocalContext.current

    var code by remember { mutableStateOf(productToEdit?.code ?: "") }
    var name by remember { mutableStateOf(productToEdit?.name ?: "") }
    var price by remember { mutableStateOf(productToEdit?.price?.toInt()?.toString() ?: "") }
    var desc by remember { mutableStateOf(productToEdit?.description ?: "") }
    var stock by remember { mutableStateOf(productToEdit?.stock?.toString() ?: "10") }
    var category by remember { mutableStateOf(productToEdit?.category ?: "Digital File") }
    var buyUrl by remember { mutableStateOf(productToEdit?.buyUrl ?: "") }
    var imageUrl by remember { mutableStateOf(productToEdit?.imageUrl ?: "") }
    var bkash by remember { mutableStateOf(productToEdit?.bkashNumber ?: "") }
    var nagad by remember { mutableStateOf(productToEdit?.nagadNumber ?: "") }
    var rocket by remember { mutableStateOf(productToEdit?.rocketNumber ?: "") }
    var isAvailable by remember { mutableStateOf(productToEdit?.isAvailable ?: true) }

    // File Picker Launcher for Digital Product
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Ignore if not supported
            }
            buyUrl = it.toString()
            Toast.makeText(context, "ডিজিটাল ফাইল মেমোরি থেকে সিলেক্ট করা হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    // Image Picker Launcher for Product Photo
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Ignore if not supported
            }
            imageUrl = it.toString()
            Toast.makeText(context, "পণ্যের ছবি মেমোরি থেকে নির্বাচন করা হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (productToEdit == null) "নতুন প্রোডাক্ট যোগ করুন" else "প্রোডাক্ট সেটিংস এডিট করুন",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Bot Marketing Active Toggle
                Surface(
                    color = if (isAvailable) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🤖 বট মার্কেটিং সেবা চালু রাখুন",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Switch(
                            checked = isAvailable,
                            onCheckedChange = { isAvailable = it }
                        )
                    }
                }

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("প্রোডাক্ট কোড (যেমন: P101, HEADPHONES)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("পণ্যের নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = price,
                        onValueChange = { price = it },
                        label = { Text("মূল্য (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = stock,
                        onValueChange = { stock = it },
                        label = { Text("স্টক সংখ্যা") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("পণ্যের বিস্তারিত বিবরণ (Marketing Description)") },
                        placeholder = { Text("পণ্যের সকল সুবিধা, ফিচার, সাইজ, ওয়ারেন্টি বা ব্যবহার করার নিয়ম বিস্তারিত লিখুন...") },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "💡 AI এই বিবরণী থেকে সব তথ্য নিয়ে কাস্টমারকে আকর্ষণীয় প্রোডাক্ট মার্কেটিং করবে।",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Divider()

                // Section 1: Digital Product Drive / File Link / Direct Deliverable
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "১. ডিজিটাল প্রোডাক্ট ড্রাইভ / ডাইরেক্ট ফাইল / লিংক:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "অর্ডার ভেরিফাইড ও কনফার্ম হলে কাস্টমারকে অটোমেটিক এই লিংক/ফাইল প্রদান করা হবে:",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline
                    )

                    OutlinedTextField(
                        value = buyUrl,
                        onValueChange = { buyUrl = it },
                        label = { Text("গুগল ড্রাইভ লিংক / টেক্সট / ডাইরেক্ট ফাইল") },
                        placeholder = { Text("https://drive.google.com/drive/folders/...\nঅথবা আপনার প্রয়োজনীয় ডাউলোড টেক্সট লিখুন...") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { filePickerLauncher.launch(arrayOf("*/*")) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("মেমোরি থেকে ফাইল", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clipData = clipboard.primaryClip
                                if (clipData != null && clipData.itemCount > 0) {
                                    val text = clipData.getItemAt(0).text.toString()
                                    if (text.isNotBlank()) {
                                        buyUrl = text
                                        Toast.makeText(context, "ক্লিপবোর্ড থেকে লিংক পেস্ট হয়েছে!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("পেস্ট", fontSize = 11.sp)
                        }
                    }
                }

                Divider()

                // Section 2: Product Image Upload / Link
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "২. পণ্যের ছবি (Product Photo Image):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )

                    if (imageUrl.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(8.dp)
                        ) {
                            AsyncImage(
                                model = imageUrl,
                                contentDescription = "Preview",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text("নির্বাচিত ছবি প্রিভিউ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                Text(imageUrl.take(35) + "...", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                            }
                            IconButton(onClick = { imageUrl = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = imageUrl,
                        onValueChange = { imageUrl = it },
                        label = { Text("ছবির লিংক বা ফাইল ইউআরআই (Image URL)") },
                        placeholder = { Text("https://example.com/photo.jpg অথবা মেমোরি থেকে নির্বাচন করুন") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("মেমোরি থেকে ছবি বাছুন", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clipData = clipboard.primaryClip
                                if (clipData != null && clipData.itemCount > 0) {
                                    val text = clipData.getItemAt(0).text.toString()
                                    if (text.isNotBlank()) {
                                        imageUrl = text
                                        Toast.makeText(context, "ছবি লিংক পেস্ট হয়েছে!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("পেস্ট", fontSize = 11.sp)
                        }
                    }
                }

                Divider()

                // Section 3: Product-Specific Custom Payment Numbers (Optional override)
                Text("৩. বিশেষ পণ্যভিত্তিক বিকাশ/নগদ নম্বর (ঐচ্ছিক):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = bkash,
                    onValueChange = { bkash = it },
                    label = { Text("🌸 বিকাশ নম্বর (ফাঁকা রাখলে সেটিংসের নম্বর যাবে)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = nagad,
                    onValueChange = { nagad = it },
                    label = { Text("🟠 নগদ নম্বর (ফাঁকা রাখলে সেটিংসের নম্বর যাবে)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = rocket,
                    onValueChange = { rocket = it },
                    label = { Text("🚀 রকেট নম্বর (ফাঁকা রাখলে সেটিংসের নম্বর যাবে)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            ThreeDButton(
                onClick = {
                    val p = price.replace(",", "").toDoubleOrNull() ?: 0.0
                    val s = stock.filter { it.isDigit() }.toIntOrNull() ?: 10
                    val finalName = if (name.isBlank()) "নতুন প্রোডাক্ট" else name.trim()
                    val finalCode = if (code.isBlank()) "P${(100..999).random()}" else code.trim()

                    onConfirm(
                        finalCode,
                        finalName,
                        p,
                        desc.trim(),
                        s,
                        category,
                        buyUrl.trim(),
                        imageUrl.trim(),
                        bkash.trim(),
                        nagad.trim(),
                        rocket.trim(),
                        "",
                        isAvailable
                    )
                },
                gradientColors = ThreeDColors.EmeraldGreen,
                bottomColor = ThreeDColors.GreenBottom,
                bottomDepth = 3.dp,
                cornerRadius = 12.dp
            ) {
                Text("সেভ করুন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
