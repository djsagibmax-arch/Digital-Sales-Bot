package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.ThreeDButton
import com.example.ui.components.ThreeDColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TestBotDialog(
    isSimulating: Boolean,
    testReply: String?,
    onDismiss: () -> Unit,
    onSimulate: (sender: String, platform: String, messageText: String) -> Unit
) {
    var senderName by remember { mutableStateOf("Customer Test") }
    var selectedPlatform by remember { mutableStateOf("WhatsApp") }
    var inputMessage by remember { mutableStateOf("দাম কত?") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SmartToy, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("সেলস বট টেস্ট সিমুলেটর", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "মেসেজ পাঠিয়ে পরীক্ষা করুন বট কী উত্তর দেয়:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )

                OutlinedTextField(
                    value = senderName,
                    onValueChange = { senderName = it },
                    label = { Text("কাস্টমার এর নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = inputMessage,
                    onValueChange = { inputMessage = it },
                    label = { Text("টেস্ট মেসেজ (যেমন: 'দাম কত', 'P101', 'hello')") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                ThreeDButton(
                    onClick = {
                        if (inputMessage.isNotBlank()) {
                            onSimulate(senderName, selectedPlatform, inputMessage)
                        }
                    },
                    enabled = !isSimulating && inputMessage.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    gradientColors = ThreeDColors.PurplePrimary,
                    bottomColor = ThreeDColors.PurpleBottom
                ) {
                    if (isSimulating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = androidx.compose.ui.graphics.Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("প্রসেস হচ্ছে...", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("মেসেজ পাঠান ও টেস্ট করুন", fontWeight = FontWeight.Bold)
                    }
                }

                if (testReply != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(16.dp)
                    ) {
                        Column {
                            Text(
                                text = "🤖 বটের উত্তর (Bot Response):",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = testReply,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("বন্ধ করুন", fontWeight = FontWeight.Bold)
            }
        }
    )
}
