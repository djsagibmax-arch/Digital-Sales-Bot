package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.CustomerOrder
import com.example.ui.SalesBotUiState
import com.example.ui.components.ThreeDButton
import com.example.ui.components.ThreeDChip
import com.example.ui.components.ThreeDColors
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersScreen(
    state: SalesBotUiState,
    onUpdateOrderStatus: (Long, String) -> Unit,
    onDeleteOrder: (CustomerOrder) -> Unit,
    onAddManualOrder: (
        name: String,
        phone: String,
        address: String,
        productName: String,
        productCode: String,
        price: Double,
        paymentMethod: String,
        trxId: String
    ) -> Unit,
    onAddBkashTx: (trxId: String, phone: String, amount: Double, method: String) -> Unit = { _, _, _, _ -> }
) {
    val context = LocalContext.current
    var selectedStatusFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var showAddBkashDialog by remember { mutableStateOf(false) }
    var showBkashSection by remember { mutableStateOf(false) }

    val filteredOrders = remember(state.orders, selectedStatusFilter, searchQuery) {
        state.orders.filter { order ->
            val matchesFilter = when (selectedStatusFilter) {
                "ALL" -> true
                else -> order.status == selectedStatusFilter
            }
            val matchesQuery = searchQuery.isBlank() ||
                    order.customerName.contains(searchQuery, ignoreCase = true) ||
                    order.customerPhone.contains(searchQuery, ignoreCase = true) ||
                    order.orderId.contains(searchQuery, ignoreCase = true) ||
                    order.productName.contains(searchQuery, ignoreCase = true) ||
                    order.trxId.contains(searchQuery, ignoreCase = true)

            matchesFilter && matchesQuery
        }
    }

    val pendingCount = remember(state.orders) { state.orders.count { it.status == CustomerOrder.STATUS_PENDING } }
    val verifiedCount = remember(state.orders) { state.orders.count { it.status == CustomerOrder.STATUS_VERIFIED } }
    val totalRevenue = remember(state.orders) {
        state.orders
            .filter { it.status == CustomerOrder.STATUS_VERIFIED || it.status == CustomerOrder.STATUS_COMPLETED || it.status == CustomerOrder.STATUS_SHIPPED }
            .sumOf { it.totalPrice }
    }

    Scaffold(
        floatingActionButton = {
            ThreeDButton(
                onClick = { showAddDialog = true },
                gradientColors = ThreeDColors.PurplePrimary,
                bottomColor = ThreeDColors.PurpleBottom,
                cornerRadius = 24.dp,
                bottomDepth = 5.dp
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add Manual Order", fontWeight = FontWeight.Bold)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
        ) {
            // Header Stats Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Total Orders", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                            Text("${state.orders.size}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Pending Payment", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                            Text("$pendingCount", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Verified Sales", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
                            Text("৳${totalRevenue.toInt()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            // bKash SMS Inbox Verification Ledger Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Payment Inbox Verification Ledger", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("Received Payment SMS (${state.bkashTransactions.size} Total)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                }
                            }

                            IconButton(onClick = { showBkashSection = !showBkashSection }) {
                                Icon(
                                    if (showBkashSection) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = "Expand Ledger"
                                )
                            }
                        }

                        if (showBkashSection) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Payment messages received:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                TextButton(onClick = { showAddBkashDialog = true }) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Test Payment SMS", fontSize = 12.sp)
                                }
                            }

                            if (state.bkashTransactions.isEmpty()) {
                                Text("No payment messages added yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    state.bkashTransactions.take(5).forEach { tx ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(MaterialTheme.colorScheme.surface)
                                                .padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text("TrxID: ${tx.trxId}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                                Text("Sender: ${tx.senderPhone} (${tx.paymentMethod})", style = MaterialTheme.typography.labelSmall)
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("৳${tx.amount.toInt()}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                AssistChip(
                                                    onClick = {},
                                                    label = { Text(if (tx.isClaimed) "Verified" else "Available", fontSize = 10.sp) },
                                                    colors = AssistChipDefaults.assistChipColors(
                                                        containerColor = if (tx.isClaimed) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search name, phone, TrxID or Order ID...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = null)
                            }
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            // Status Filter Chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val filters = listOf(
                        "ALL" to "All (${state.orders.size})",
                        CustomerOrder.STATUS_PENDING to "Pending ($pendingCount)",
                        CustomerOrder.STATUS_VERIFIED to "Verified ($verifiedCount)",
                        CustomerOrder.STATUS_SHIPPED to "Shipped",
                        CustomerOrder.STATUS_COMPLETED to "Completed",
                        CustomerOrder.STATUS_CANCELLED to "Cancelled"
                    )

                    filters.forEach { (statusKey, labelText) ->
                        ThreeDChip(
                            selected = selectedStatusFilter == statusKey,
                            onClick = { selectedStatusFilter = statusKey },
                            label = labelText,
                            selectedGradient = when (statusKey) {
                                CustomerOrder.STATUS_PENDING -> ThreeDColors.CoralOrange
                                CustomerOrder.STATUS_VERIFIED -> ThreeDColors.EmeraldGreen
                                else -> ThreeDColors.BluePrimary
                            },
                            selectedBottomColor = when (statusKey) {
                                CustomerOrder.STATUS_PENDING -> ThreeDColors.OrangeBottom
                                CustomerOrder.STATUS_VERIFIED -> ThreeDColors.GreenBottom
                                else -> ThreeDColors.BlueBottom
                            }
                        )
                    }
                }
            }

            // Order List Items
            if (filteredOrders.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 24.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No orders found", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Orders placed by customers via auto-reply or added manually will appear here.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            } else {
                items(filteredOrders, key = { it.id }) { order ->
                    OrderItemCard(
                        order = order,
                        onUpdateStatus = { newStatus -> onUpdateOrderStatus(order.id, newStatus) },
                        onDelete = { onDeleteOrder(order) },
                        onCall = {
                            if (order.customerPhone.isNotBlank() && order.customerPhone != "No phone collected") {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${order.customerPhone}"))
                                context.startActivity(intent)
                            }
                        }
                    )
                }
            }
        }

        if (showAddDialog) {
            AddManualOrderDialog(
                products = state.products,
                onDismiss = { showAddDialog = false },
                onConfirm = { name, phone, address, pName, pCode, price, method, trx ->
                    onAddManualOrder(name, phone, address, pName, pCode, price, method, trx)
                    showAddDialog = false
                }
            )
        }

        if (showAddBkashDialog) {
            AddBkashTxDialog(
                onDismiss = { showAddBkashDialog = false },
                onConfirm = { trxId, phone, amount, method ->
                    onAddBkashTx(trxId, phone, amount, method)
                    showAddBkashDialog = false
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderItemCard(
    order: CustomerOrder,
    onUpdateStatus: (String) -> Unit,
    onDelete: () -> Unit,
    onCall: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("hh:mm a, dd MMM yyyy", Locale.getDefault()) }
    val formattedDate = remember(order.orderDate) { dateFormat.format(Date(order.orderDate)) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Order ID & Status Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = order.orderId,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    AssistChip(
                        onClick = {},
                        label = { Text(order.platform, fontSize = 11.sp) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (order.status) {
                        CustomerOrder.STATUS_VERIFIED -> MaterialTheme.colorScheme.primaryContainer
                        CustomerOrder.STATUS_SHIPPED -> MaterialTheme.colorScheme.tertiaryContainer
                        CustomerOrder.STATUS_COMPLETED -> MaterialTheme.colorScheme.secondaryContainer
                        CustomerOrder.STATUS_CANCELLED -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.errorContainer // Pending
                    }
                ) {
                    Text(
                        text = when (order.status) {
                            CustomerOrder.STATUS_VERIFIED -> "Payment Verified"
                            CustomerOrder.STATUS_SHIPPED -> "Shipped (In Transit)"
                            CustomerOrder.STATUS_COMPLETED -> "Completed"
                            CustomerOrder.STATUS_CANCELLED -> "Cancelled"
                            else -> "Payment Pending"
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (order.status) {
                            CustomerOrder.STATUS_CANCELLED -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Customer Info
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.width(6.dp))
                Text(order.customerName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                Spacer(modifier = Modifier.weight(1f))
                Text(formattedDate, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.width(6.dp))
                Text(order.customerPhone, style = MaterialTheme.typography.bodyMedium)
            }

            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(18.dp).padding(top = 2.dp), tint = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.width(6.dp))
                Text(order.deliveryAddress, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }

            Divider(modifier = Modifier.padding(vertical = 10.dp))

            // Product & Payment Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Product: ${order.productName}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Text("Payment Method: ${order.paymentMethod} ${if (order.trxId != "N/A") "(TrxID: ${order.trxId})" else ""}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                Text("৳${order.totalPrice.toInt()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (order.status == CustomerOrder.STATUS_PENDING) {
                    ThreeDButton(
                        onClick = { onUpdateStatus(CustomerOrder.STATUS_VERIFIED) },
                        gradientColors = ThreeDColors.EmeraldGreen,
                        bottomColor = ThreeDColors.GreenBottom,
                        cornerRadius = 10.dp,
                        bottomDepth = 3.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Verify Payment", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    OutlinedButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Change Status", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("PENDING") },
                            onClick = { onUpdateStatus(CustomerOrder.STATUS_PENDING); showMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("VERIFIED") },
                            onClick = { onUpdateStatus(CustomerOrder.STATUS_VERIFIED); showMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("SHIPPED") },
                            onClick = { onUpdateStatus(CustomerOrder.STATUS_SHIPPED); showMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("COMPLETED") },
                            onClick = { onUpdateStatus(CustomerOrder.STATUS_COMPLETED); showMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("CANCELLED") },
                            onClick = { onUpdateStatus(CustomerOrder.STATUS_CANCELLED); showMenu = false }
                        )
                    }
                }

                IconButton(
                    onClick = onCall,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Icon(Icons.Default.Call, contentDescription = "Call Customer")
                }

                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Order", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
fun AddManualOrderDialog(
    products: List<com.example.data.db.Product>,
    onDismiss: () -> Unit,
    onConfirm: (
        name: String,
        phone: String,
        address: String,
        productName: String,
        productCode: String,
        price: Double,
        paymentMethod: String,
        trxId: String
    ) -> Unit
) {
    var customerName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var selectedProductName by remember { mutableStateOf(products.firstOrNull()?.name ?: "Headphones") }
    var selectedProductCode by remember { mutableStateOf(products.firstOrNull()?.code ?: "P101") }
    var priceStr by remember { mutableStateOf(products.firstOrNull()?.price?.toString() ?: "1850") }
    var paymentMethod by remember { mutableStateOf("bKash") }
    var trxId by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Manual Order", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text("Customer Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number (e.g. 01711223344)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Delivery Address") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = selectedProductName,
                    onValueChange = { selectedProductName = it },
                    label = { Text("Product Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = priceStr,
                    onValueChange = { priceStr = it },
                    label = { Text("Price (৳)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Payment Method:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("bKash", "Nagad", "Rocket", "Cash on Delivery").forEach { method ->
                        ThreeDChip(
                            selected = paymentMethod == method,
                            onClick = { paymentMethod = method },
                            label = method,
                            selectedGradient = ThreeDColors.BluePrimary,
                            selectedBottomColor = ThreeDColors.BlueBottom
                        )
                    }
                }

                OutlinedTextField(
                    value = trxId,
                    onValueChange = { trxId = it },
                    label = { Text("Transaction ID / TrxID (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            ThreeDButton(
                onClick = {
                    val p = priceStr.toDoubleOrNull() ?: 0.0
                    if (customerName.isNotBlank() && phone.isNotBlank()) {
                        onConfirm(customerName, phone, address, selectedProductName, selectedProductCode, p, paymentMethod, trxId.ifBlank { "N/A" })
                    }
                },
                gradientColors = ThreeDColors.PurplePrimary,
                bottomColor = ThreeDColors.PurpleBottom,
                cornerRadius = 12.dp,
                bottomDepth = 3.dp
            ) {
                Text("Create Order", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddBkashTxDialog(
    onDismiss: () -> Unit,
    onConfirm: (trxId: String, phone: String, amount: Double, method: String) -> Unit
) {
    var trxId by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("1850") }
    var method by remember { mutableStateOf("bKash") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Test Payment SMS", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Enter TrxID and amount to simulate incoming payment SMS from bKash or Nagad:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)

                OutlinedTextField(
                    value = trxId,
                    onValueChange = { trxId = it },
                    label = { Text("TrxID (e.g. BK889900)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Sender Phone Number (e.g. 01711223344)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Amount (৳)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Payment Channel:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("bKash", "Nagad", "Rocket").forEach { channel ->
                        FilterChip(
                            selected = method == channel,
                            onClick = { method = channel },
                            label = { Text(channel) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            ThreeDButton(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    if (trxId.isNotBlank()) {
                        onConfirm(trxId.trim().uppercase(), phone.ifBlank { "01700000000" }, amt, method)
                    }
                },
                gradientColors = ThreeDColors.EmeraldGreen,
                bottomColor = ThreeDColors.GreenBottom,
                cornerRadius = 12.dp,
                bottomDepth = 3.dp
            ) {
                Text("Save Payment", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
