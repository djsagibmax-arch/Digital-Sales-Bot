package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.db.AutoReplyRule
import com.example.ui.SalesBotUiState
import com.example.ui.components.ThreeDButton
import com.example.ui.components.ThreeDChip
import com.example.ui.components.ThreeDColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RulesScreen(
    state: SalesBotUiState,
    onAddRule: (String, String, String, String) -> Unit,
    onToggleRule: (AutoReplyRule) -> Unit,
    onDeleteRule: (AutoReplyRule) -> Unit,
    onSaveAutoFollowupSettings: (enabled: Boolean, message: String, trigger: String) -> Unit = { _, _, _ -> }
) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }

    var isFollowupEnabled by remember(state.isAutoFollowupEnabled) { mutableStateOf(state.isAutoFollowupEnabled) }
    var followupMessageText by remember(state.autoFollowupMessage) { mutableStateOf(state.autoFollowupMessage) }
    var followupTrigger by remember(state.autoFollowupTrigger) { mutableStateOf(state.autoFollowupTrigger) }

    Scaffold(
        floatingActionButton = {
            ThreeDButton(
                onClick = { showAddDialog = true },
                gradientColors = ThreeDColors.PurplePrimary,
                bottomColor = ThreeDColors.PurpleBottom,
                cornerRadius = 24.dp,
                bottomDepth = 5.dp
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add New Rule", fontWeight = FontWeight.Bold)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
        ) {
            // Auto Follow-up Instant Reply Card at the VERY TOP
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    Icons.Default.Send,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "💬 Auto Instant Reply / Follow-up Message",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Automatically send a custom follow-up message to the customer 1-2s after reply:",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                            Switch(
                                checked = isFollowupEnabled,
                                onCheckedChange = { isFollowupEnabled = it }
                            )
                        }

                        if (isFollowupEnabled) {
                            Divider()

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Custom Follow-up Message:",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                                OutlinedTextField(
                                    value = followupMessageText,
                                    onValueChange = { followupMessageText = it },
                                    placeholder = { Text("e.g. Thank you! For immediate orders, please call 017XXXXXXXX or visit our website...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 3,
                                    maxLines = 5,
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "When to send this message? (Select Trigger Type):",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    ThreeDChip(
                                        selected = followupTrigger == "CUSTOMER",
                                        onClick = { followupTrigger = "CUSTOMER" },
                                        label = "👤 After Customer Message",
                                        selectedGradient = ThreeDColors.EmeraldGreen,
                                        selectedBottomColor = ThreeDColors.GreenBottom
                                    )

                                    ThreeDChip(
                                        selected = followupTrigger == "ROBOT",
                                        onClick = { followupTrigger = "ROBOT" },
                                        label = "🤖 After AI Reply",
                                        selectedGradient = ThreeDColors.EmeraldGreen,
                                        selectedBottomColor = ThreeDColors.GreenBottom
                                    )

                                    ThreeDChip(
                                        selected = followupTrigger == "BOTH",
                                        onClick = { followupTrigger = "BOTH" },
                                        label = "🔄 After Both Messages",
                                        selectedGradient = ThreeDColors.EmeraldGreen,
                                        selectedBottomColor = ThreeDColors.GreenBottom
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            ThreeDButton(
                                onClick = {
                                    onSaveAutoFollowupSettings(
                                        isFollowupEnabled,
                                        followupMessageText,
                                        followupTrigger
                                    )
                                    Toast.makeText(context, "Auto follow-up settings saved!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                gradientColors = ThreeDColors.EmeraldGreen,
                                bottomColor = ThreeDColors.GreenBottom,
                                cornerRadius = 16.dp
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Save Auto Reply Settings", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                Divider()
                Spacer(modifier = Modifier.height(4.dp))
            }

            item {
                Text(
                    text = "Keyword Auto-Reply Rules (${state.rules.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "When customer message matches specific keywords, the bot responds automatically.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            if (state.rules.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 32.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Rule, contentDescription = null, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Rules Created Yet", fontWeight = FontWeight.Bold)
                            Text("Tap the '+' button below to add keywords and auto-responses.")
                        }
                    }
                }
            } else {
                items(state.rules, key = { it.id }) { rule ->
                    RuleItemCard(
                        rule = rule,
                        onToggle = { onToggleRule(rule) },
                        onDelete = { onDeleteRule(rule) }
                    )
                }
            }
        }

        if (showAddDialog) {
            AddRuleDialog(
                onDismiss = { showAddDialog = false },
                onConfirm = { keyword, response, matchType, category ->
                    onAddRule(keyword, response, matchType, category)
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
fun RuleItemCard(
    rule: AutoReplyRule,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(
                        onClick = {},
                        label = { Text(rule.matchType) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Category: ${rule.category}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = rule.isEnabled, onCheckedChange = { onToggle() })
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "🔑 Keyword: \"${rule.keyword}\"",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "💬 Reply: ${rule.response}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Used: ${rule.usageCount} times",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun AddRuleDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String) -> Unit
) {
    var keyword by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("") }
    var matchType by remember { mutableStateOf(AutoReplyRule.MATCH_CONTAINS) }
    var category by remember { mutableStateOf("Sales") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Auto-Reply Rule", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = keyword,
                    onValueChange = { keyword = it },
                    label = { Text("Keyword (e.g. price, cost)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = response,
                    onValueChange = { response = it },
                    label = { Text("Auto-Response Message") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category (e.g. Pricing, Order)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Matching Type:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThreeDChip(
                        selected = matchType == AutoReplyRule.MATCH_CONTAINS,
                        onClick = { matchType = AutoReplyRule.MATCH_CONTAINS },
                        label = "Contains",
                        selectedGradient = ThreeDColors.BluePrimary,
                        selectedBottomColor = ThreeDColors.BlueBottom
                    )
                    ThreeDChip(
                        selected = matchType == AutoReplyRule.MATCH_EXACT,
                        onClick = { matchType = AutoReplyRule.MATCH_EXACT },
                        label = "Exact Match",
                        selectedGradient = ThreeDColors.PurplePrimary,
                        selectedBottomColor = ThreeDColors.PurpleBottom
                    )
                }
            }
        },
        confirmButton = {
            ThreeDButton(
                onClick = {
                    if (keyword.isNotBlank() && response.isNotBlank()) {
                        onConfirm(keyword, response, matchType, category)
                    }
                },
                gradientColors = ThreeDColors.EmeraldGreen,
                bottomColor = ThreeDColors.GreenBottom,
                bottomDepth = 3.dp,
                cornerRadius = 12.dp
            ) {
                Text("Save Rule", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
