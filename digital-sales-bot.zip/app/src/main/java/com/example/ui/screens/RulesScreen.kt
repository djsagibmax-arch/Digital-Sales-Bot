package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.db.AutoReplyRule
import com.example.ui.SalesBotUiState
import com.example.ui.components.ThreeDButton
import com.example.ui.components.ThreeDChip
import com.example.ui.components.ThreeDColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RulesScreen(
    state: SalesBotUiState,
    onAddRule: (String, String, String, String) -> Unit,
    onToggleRule: (AutoReplyRule) -> Unit,
    onDeleteRule: (AutoReplyRule) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            ThreeDButton(
                onClick = { showAddDialog = true },
                gradientColors = ThreeDColors.PurplePrimary,
                bottomColor = ThreeDColors.PurpleBottom,
                cornerRadius = 24.dp,
                bottomDepth = 5.dp
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("নতুন রুল যোগ করুন", fontWeight = FontWeight.Bold)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
        ) {
            item {
                Text(
                    text = "কীওয়ার্ড অটো-রিপ্লাই রুলস (${state.rules.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "গ্রাহকের মেসেজে নির্দিষ্ট শব্দ মিললে রোবট স্বয়ংক্রিয়ভাবে উত্তর দেবে।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            if (state.rules.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 32.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Rule, contentDescription = null, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("কোনো রুলস তৈরি করা হয়নি", fontWeight = FontWeight.Bold)
                            Text("নিচের '+' বাটনে চাপ দিয়ে কীওয়ার্ড এবং উত্তর যুক্ত করুন।")
                        }
                    }
                }
            } else {
                items(state.rules, key = { it.id }) { rule ->
                    RuleItemCard(
                        rule = rule,
                        onToggle = { onToggleRule(rule) },
                        onDelete = { onDeleteRule(rule) }
                    )
                }
            }
        }

        if (showAddDialog) {
            AddRuleDialog(
                onDismiss = { showAddDialog = false },
                onConfirm = { keyword, response, matchType, category ->
                    onAddRule(keyword, response, matchType, category)
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
fun RuleItemCard(
    rule: AutoReplyRule,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(
                        onClick = {},
                        label = { Text(rule.matchType) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ক্যাটাগরি: ${rule.category}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = rule.isEnabled, onCheckedChange = { onToggle() })
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "🔑 কীওয়ার্ড: \"${rule.keyword}\"",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "💬 উত্তর: ${rule.response}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "ব্যবহার হয়েছে: ${rule.usageCount} বার",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun AddRuleDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String) -> Unit
) {
    var keyword by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("") }
    var matchType by remember { mutableStateOf(AutoReplyRule.MATCH_CONTAINS) }
    var category by remember { mutableStateOf("Sales") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন অটো-রিপ্লাই রুলস", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = keyword,
                    onValueChange = { keyword = it },
                    label = { Text("কীওয়ার্ড (যেমন: দাম কত, price)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = response,
                    onValueChange = { response = it },
                    label = { Text("অটোমেটিক উত্তর মেসেজ") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("ক্যাটাগরি (যেমন: Pricing, Order)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("ম্যাচিং টাইপ:", style = MaterialTheme.typography.labelMedium)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThreeDChip(
                        selected = matchType == AutoReplyRule.MATCH_CONTAINS,
                        onClick = { matchType = AutoReplyRule.MATCH_CONTAINS },
                        label = "Contains (মেলে)",
                        selectedGradient = ThreeDColors.BluePrimary,
                        selectedBottomColor = ThreeDColors.BlueBottom
                    )
                    ThreeDChip(
                        selected = matchType == AutoReplyRule.MATCH_EXACT,
                        onClick = { matchType = AutoReplyRule.MATCH_EXACT },
                        label = "Exact (হুবহু)",
                        selectedGradient = ThreeDColors.PurplePrimary,
                        selectedBottomColor = ThreeDColors.PurpleBottom
                    )
                }
            }
        },
        confirmButton = {
            ThreeDButton(
                onClick = {
                    if (keyword.isNotBlank() && response.isNotBlank()) {
                        onConfirm(keyword, response, matchType, category)
                    }
                },
                gradientColors = ThreeDColors.EmeraldGreen,
                bottomColor = ThreeDColors.GreenBottom,
                bottomDepth = 3.dp,
                cornerRadius = 12.dp
            ) {
                Text("সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
