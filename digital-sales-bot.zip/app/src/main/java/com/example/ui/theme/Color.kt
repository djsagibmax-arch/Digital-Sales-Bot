package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Indigo600 = Color(0xFF4F46E5)
val Indigo700 = Color(0xFF4338CA)
val Indigo900 = Color(0xFF1E1B4B)

val Cyan400 = Color(0xFF22D3EE)
val Cyan500 = Color(0xFF06B6D4)

val Emerald500 = Color(0xFF10B981)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate100 = Color(0xFFF1F5F9)

val PrimaryLight = Color(0xFF4F46E5)
val SecondaryLight = Color(0xFF06B6D4)
val TertiaryLight = Color(0xFF10B981)

val PrimaryDark = Color(0xFF818CF8)
val SecondaryDark = Color(0xFF67E8F9)
val TertiaryDark = Color(0xFF34D399)

