package com.example.ui

import android.app.Application
import android.content.Context
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AutoReplyRule
import com.example.data.db.Product
import com.example.data.db.SalesLead
import com.example.data.repository.SalesRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SalesBotUiState(
    val rules: List<AutoReplyRule> = emptyList(),
    val products: List<Product> = emptyList(),
    val leads: List<SalesLead> = emptyList(),
    val isBotActive: Boolean = true,
    val isAiEnabled: Boolean = true,
    val replyDelaySeconds: Int = 1,
    val customPrompt: String = "",
    val customApiKey: String = "",
    val whatsappEnabled: Boolean = true,
    val messengerEnabled: Boolean = true,
    val smsEnabled: Boolean = true,
    val telegramEnabled: Boolean = true,
    val isNotificationAccessGranted: Boolean = false,
    val testSimulationReply: String? = null,
    val isSimulating: Boolean = false
)

class SalesBotViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SalesRepository(application)

    private val _testSimulationReply = MutableStateFlow<String?>(null)
    private val _isSimulating = MutableStateFlow(false)

    val uiState: StateFlow<SalesBotUiState> = combine(
        repository.allRules,
        repository.allProducts,
        repository.allLeads,
        _testSimulationReply,
        _isSimulating
    ) { rules, products, leads, testReply, isSim ->
        SalesBotUiState(
            rules = rules,
            products = products,
            leads = leads,
            isBotActive = repository.isBotActive,
            isAiEnabled = repository.isAiEnabled,
            replyDelaySeconds = repository.replyDelaySeconds,
            customPrompt = repository.customPrompt,
            customApiKey = repository.customApiKey,
            whatsappEnabled = repository.whatsappEnabled,
            messengerEnabled = repository.messengerEnabled,
            smsEnabled = repository.smsEnabled,
            telegramEnabled = repository.telegramEnabled,
            isNotificationAccessGranted = checkNotificationAccessGranted(getApplication()),
            testSimulationReply = testReply,
            isSimulating = isSim
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SalesBotUiState()
    )

    fun refreshPermissionStatus() {
        viewModelScope.launch {
            _testSimulationReply.value = _testSimulationReply.value
        }
    }

    fun toggleBotActive(active: Boolean) {
        repository.isBotActive = active
        refreshPermissionStatus()
    }

    fun toggleAiEnabled(enabled: Boolean) {
        repository.isAiEnabled = enabled
        refreshPermissionStatus()
    }

    fun setReplyDelay(seconds: Int) {
        repository.replyDelaySeconds = seconds
        refreshPermissionStatus()
    }

    fun saveAiPromptAndKey(prompt: String, apiKey: String) {
        repository.customPrompt = prompt
        repository.customApiKey = apiKey
        refreshPermissionStatus()
    }

    fun togglePlatform(platform: String, enabled: Boolean) {
        when (platform) {
            "WhatsApp" -> repository.whatsappEnabled = enabled
            "Messenger" -> repository.messengerEnabled = enabled
            "SMS" -> repository.smsEnabled = enabled
            "Telegram" -> repository.telegramEnabled = enabled
        }
        refreshPermissionStatus()
    }

    fun addRule(keyword: String, response: String, matchType: String, category: String) {
        viewModelScope.launch {
            repository.insertRule(
                AutoReplyRule(
                    keyword = keyword,
                    response = response,
                    matchType = matchType,
                    category = category
                )
            )
        }
    }

    fun toggleRuleStatus(rule: AutoReplyRule) {
        viewModelScope.launch {
            repository.updateRule(rule.copy(isEnabled = !rule.isEnabled))
        }
    }

    fun deleteRule(rule: AutoReplyRule) {
        viewModelScope.launch {
            repository.deleteRule(rule)
        }
    }

    fun addProduct(code: String, name: String, price: Double, description: String, stock: Int, category: String, buyUrl: String) {
        viewModelScope.launch {
            repository.insertProduct(
                Product(
                    code = code,
                    name = name,
                    price = price,
                    description = description,
                    stock = stock,
                    category = category,
                    buyUrl = buyUrl
                )
            )
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    fun clearLeads() {
        viewModelScope.launch {
            repository.clearLeads()
        }
    }

    fun simulateMessage(sender: String, platform: String, text: String) {
        viewModelScope.launch {
            _isSimulating.value = true
            val reply = repository.processIncomingMessage(sender, platform, text)
            _testSimulationReply.value = reply
            _isSimulating.value = false
        }
    }

    fun clearSimulationResult() {
        _testSimulationReply.value = null
    }

    private fun checkNotificationAccessGranted(context: Context): Boolean {
        val pkgName = context.packageName
        val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(pkgName)
    }
}
