package com.example.ui

import android.app.Application
import android.content.Context
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AutoReplyRule
import com.example.data.db.BkashTransaction
import com.example.data.db.CustomerOrder
import com.example.data.db.Product
import com.example.data.db.SalesLead
import com.example.data.repository.SalesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class BotSettings(
    val isBotActive: Boolean = true,
    val isAiEnabled: Boolean = true,
    val isAutoFollowupEnabled: Boolean = false,
    val autoFollowupMessage: String = "",
    val autoFollowupTrigger: String = "BOTH",
    val autoFollowupDelaySeconds: Int = 5,
    val replyDelaySeconds: Int = 5,
    val customPrompt: String = "",
    val customApiKey: String = "",
    val aiProvider: String = "Gemini",
    val geminiApiKey: String = "",
    val geminiModel: String = "gemini-2.0-flash",
    val groqApiKey: String = "",
    val groqModel: String = "llama-3.1-8b-instant",
    val chatgptApiKey: String = "",
    val chatgptModel: String = "gpt-4o-mini",
    val whatsappEnabled: Boolean = true,
    val messengerEnabled: Boolean = true,
    val smsEnabled: Boolean = true,
    val telegramEnabled: Boolean = true,
    val isBkashEnabled: Boolean = true,
    val bkashNumber: String = "",
    val isNagadEnabled: Boolean = true,
    val nagadNumber: String = "",
    val isRocketEnabled: Boolean = false,
    val rocketNumber: String = "",
    val isNotificationAccessGranted: Boolean = false
)

data class SalesBotUiState(
    val rules: List<AutoReplyRule> = emptyList(),
    val products: List<Product> = emptyList(),
    val leads: List<SalesLead> = emptyList(),
    val orders: List<CustomerOrder> = emptyList(),
    val bkashTransactions: List<BkashTransaction> = emptyList(),
    val isBotActive: Boolean = true,
    val isAiEnabled: Boolean = true,
    val isAutoFollowupEnabled: Boolean = false,
    val autoFollowupMessage: String = "",
    val autoFollowupTrigger: String = "BOTH",
    val autoFollowupDelaySeconds: Int = 5,
    val replyDelaySeconds: Int = 5,
    val customPrompt: String = "",
    val customApiKey: String = "",
    val aiProvider: String = "Gemini",
    val geminiApiKey: String = "",
    val geminiModel: String = "gemini-2.0-flash",
    val groqApiKey: String = "",
    val groqModel: String = "llama-3.1-8b-instant",
    val chatgptApiKey: String = "",
    val chatgptModel: String = "gpt-4o-mini",
    val whatsappEnabled: Boolean = true,
    val messengerEnabled: Boolean = true,
    val smsEnabled: Boolean = true,
    val telegramEnabled: Boolean = true,
    val isBkashEnabled: Boolean = true,
    val bkashNumber: String = "",
    val isNagadEnabled: Boolean = true,
    val nagadNumber: String = "",
    val isRocketEnabled: Boolean = false,
    val rocketNumber: String = "",
    val isNotificationAccessGranted: Boolean = false,
    val testSimulationReply: String? = null,
    val isSimulating: Boolean = false
)

class SalesBotViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SalesRepository(application)

    private val _settings = MutableStateFlow(
        BotSettings(
            isBotActive = repository.isBotActive,
            isAiEnabled = repository.isAiEnabled,
            isAutoFollowupEnabled = repository.isAutoFollowupEnabled,
            autoFollowupMessage = repository.autoFollowupMessage,
            autoFollowupTrigger = repository.autoFollowupTrigger,
            autoFollowupDelaySeconds = repository.autoFollowupDelaySeconds,
            replyDelaySeconds = repository.replyDelaySeconds,
            customPrompt = repository.customPrompt,
            customApiKey = repository.customApiKey,
            aiProvider = repository.aiProvider,
            geminiApiKey = repository.geminiApiKey,
            geminiModel = repository.geminiModel,
            groqApiKey = repository.groqApiKey,
            groqModel = repository.groqModel,
            chatgptApiKey = repository.chatgptApiKey,
            chatgptModel = repository.chatgptModel,
            whatsappEnabled = repository.whatsappEnabled,
            messengerEnabled = repository.messengerEnabled,
            smsEnabled = repository.smsEnabled,
            telegramEnabled = repository.telegramEnabled,
            isBkashEnabled = repository.isBkashEnabled,
            bkashNumber = repository.bkashNumber,
            isNagadEnabled = repository.isNagadEnabled,
            nagadNumber = repository.nagadNumber,
            isRocketEnabled = repository.isRocketEnabled,
            rocketNumber = repository.rocketNumber,
            isNotificationAccessGranted = false
        )
    )

    private val _testSimulationReply = MutableStateFlow<String?>(null)
    private val _isSimulating = MutableStateFlow(false)

    init {
        refreshPermissionStatus()
        viewModelScope.launch(Dispatchers.IO) {
            repository.purgeDummyProducts()
        }
    }

    private val _dbFlow = combine(
        repository.allRules,
        repository.allProducts,
        repository.allLeads,
        repository.allOrders,
        repository.allBkashTransactions
    ) { rules, products, leads, orders, bkash ->
        listOf(rules, products, leads, orders, bkash)
    }

    val uiState: StateFlow<SalesBotUiState> = combine(
        _dbFlow,
        _settings,
        _testSimulationReply,
        _isSimulating
    ) { dbData, settings, testReply, isSim ->
        @Suppress("UNCHECKED_CAST")
        val rules = dbData[0] as List<AutoReplyRule>
        @Suppress("UNCHECKED_CAST")
        val products = dbData[1] as List<Product>
        @Suppress("UNCHECKED_CAST")
        val leads = dbData[2] as List<SalesLead>
        @Suppress("UNCHECKED_CAST")
        val orders = dbData[3] as List<CustomerOrder>
        @Suppress("UNCHECKED_CAST")
        val bkashTxs = dbData[4] as List<BkashTransaction>

        SalesBotUiState(
            rules = rules,
            products = products,
            leads = leads,
            orders = orders,
            bkashTransactions = bkashTxs,
            isBotActive = settings.isBotActive,
            isAiEnabled = settings.isAiEnabled,
            isAutoFollowupEnabled = settings.isAutoFollowupEnabled,
            autoFollowupMessage = settings.autoFollowupMessage,
            autoFollowupTrigger = settings.autoFollowupTrigger,
            autoFollowupDelaySeconds = settings.autoFollowupDelaySeconds,
            replyDelaySeconds = settings.replyDelaySeconds,
            customPrompt = settings.customPrompt,
            customApiKey = settings.customApiKey,
            aiProvider = settings.aiProvider,
            geminiApiKey = settings.geminiApiKey,
            geminiModel = settings.geminiModel,
            groqApiKey = settings.groqApiKey,
            groqModel = settings.groqModel,
            chatgptApiKey = settings.chatgptApiKey,
            chatgptModel = settings.chatgptModel,
            whatsappEnabled = settings.whatsappEnabled,
            messengerEnabled = settings.messengerEnabled,
            smsEnabled = settings.smsEnabled,
            telegramEnabled = settings.telegramEnabled,
            isBkashEnabled = settings.isBkashEnabled,
            bkashNumber = settings.bkashNumber,
            isNagadEnabled = settings.isNagadEnabled,
            nagadNumber = settings.nagadNumber,
            isRocketEnabled = settings.isRocketEnabled,
            rocketNumber = settings.rocketNumber,
            isNotificationAccessGranted = settings.isNotificationAccessGranted,
            testSimulationReply = testReply,
            isSimulating = isSim
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = SalesBotUiState(
            isBotActive = repository.isBotActive,
            isAiEnabled = repository.isAiEnabled,
            isAutoFollowupEnabled = repository.isAutoFollowupEnabled,
            autoFollowupMessage = repository.autoFollowupMessage,
            autoFollowupTrigger = repository.autoFollowupTrigger,
            autoFollowupDelaySeconds = repository.autoFollowupDelaySeconds,
            replyDelaySeconds = repository.replyDelaySeconds,
            customPrompt = repository.customPrompt,
            customApiKey = repository.customApiKey,
            aiProvider = repository.aiProvider,
            geminiApiKey = repository.geminiApiKey,
            geminiModel = repository.geminiModel,
            groqApiKey = repository.groqApiKey,
            groqModel = repository.groqModel,
            chatgptApiKey = repository.chatgptApiKey,
            chatgptModel = repository.chatgptModel,
            whatsappEnabled = repository.whatsappEnabled,
            messengerEnabled = repository.messengerEnabled,
            smsEnabled = repository.smsEnabled,
            telegramEnabled = repository.telegramEnabled,
            isBkashEnabled = repository.isBkashEnabled,
            bkashNumber = repository.bkashNumber,
            isNagadEnabled = repository.isNagadEnabled,
            nagadNumber = repository.nagadNumber,
            isRocketEnabled = repository.isRocketEnabled,
            rocketNumber = repository.rocketNumber
        )
    )

    fun saveAutoFollowupSettings(enabled: Boolean, message: String, trigger: String, delaySeconds: Int = 5) {
        _settings.update {
            it.copy(
                isAutoFollowupEnabled = enabled,
                autoFollowupMessage = message,
                autoFollowupTrigger = trigger,
                autoFollowupDelaySeconds = delaySeconds
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            repository.isAutoFollowupEnabled = enabled
            repository.autoFollowupMessage = message
            repository.autoFollowupTrigger = trigger
            repository.autoFollowupDelaySeconds = delaySeconds
        }
    }

    fun refreshPermissionStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val granted = checkNotificationAccessGranted(getApplication())
            _settings.update { it.copy(isNotificationAccessGranted = granted) }
        }
    }

    fun toggleBotActive(active: Boolean) {
        _settings.update { it.copy(isBotActive = active) }
        viewModelScope.launch(Dispatchers.IO) {
            repository.isBotActive = active
        }
    }

    fun toggleAiEnabled(enabled: Boolean) {
        _settings.update { it.copy(isAiEnabled = enabled) }
        viewModelScope.launch(Dispatchers.IO) {
            repository.isAiEnabled = enabled
        }
    }

    fun setReplyDelay(seconds: Int) {
        _settings.update { it.copy(replyDelaySeconds = seconds) }
        viewModelScope.launch(Dispatchers.IO) {
            repository.replyDelaySeconds = seconds
        }
    }

    fun saveAiProviderConfig(
        provider: String,
        prompt: String,
        geminiKey: String,
        geminiModel: String,
        groqKey: String,
        groqModel: String,
        chatgptKey: String,
        chatgptModel: String
    ) {
        _settings.update {
            it.copy(
                aiProvider = provider,
                customPrompt = prompt,
                geminiApiKey = geminiKey,
                geminiModel = geminiModel,
                groqApiKey = groqKey,
                groqModel = groqModel,
                chatgptApiKey = chatgptKey,
                chatgptModel = chatgptModel
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            repository.aiProvider = provider
            repository.customPrompt = prompt
            repository.geminiApiKey = geminiKey
            repository.geminiModel = geminiModel
            repository.groqApiKey = groqKey
            repository.groqModel = groqModel
            repository.chatgptApiKey = chatgptKey
            repository.chatgptModel = chatgptModel
        }
    }

    fun saveAiPromptAndKey(prompt: String, apiKey: String) {
        _settings.update { it.copy(customPrompt = prompt, customApiKey = apiKey) }
        viewModelScope.launch(Dispatchers.IO) {
            repository.customPrompt = prompt
            repository.customApiKey = apiKey
        }
    }

    fun togglePlatform(platform: String, enabled: Boolean) {
        _settings.update { current ->
            when (platform) {
                "WhatsApp" -> current.copy(whatsappEnabled = enabled)
                "Messenger" -> current.copy(messengerEnabled = enabled)
                "SMS" -> current.copy(smsEnabled = enabled)
                "Telegram" -> current.copy(telegramEnabled = enabled)
                else -> current
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            when (platform) {
                "WhatsApp" -> repository.whatsappEnabled = enabled
                "Messenger" -> repository.messengerEnabled = enabled
                "SMS" -> repository.smsEnabled = enabled
                "Telegram" -> repository.telegramEnabled = enabled
            }
        }
    }

    fun addRule(keyword: String, response: String, matchType: String, category: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertRule(
                AutoReplyRule(
                    keyword = keyword,
                    response = response,
                    matchType = matchType,
                    category = category
                )
            )
        }
    }

    fun toggleRuleStatus(rule: AutoReplyRule) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateRule(rule.copy(isEnabled = !rule.isEnabled))
        }
    }

    fun deleteRule(rule: AutoReplyRule) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteRule(rule)
        }
    }

    fun addProduct(
        code: String,
        name: String,
        price: Double,
        description: String,
        stock: Int,
        category: String,
        buyUrl: String,
        imageUrl: String = "",
        bkashNumber: String = "01711223344",
        nagadNumber: String = "01899887766",
        rocketNumber: String = "01911223344",
        dbblNumber: String = "",
        isAvailable: Boolean = true
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertProduct(
                Product(
                    code = code,
                    name = name,
                    price = price,
                    description = description,
                    stock = stock,
                    category = category,
                    buyUrl = buyUrl,
                    imageUrl = imageUrl,
                    bkashNumber = bkashNumber,
                    nagadNumber = nagadNumber,
                    rocketNumber = rocketNumber,
                    dbblNumber = dbblNumber,
                    isAvailable = isAvailable
                )
            )
        }
    }

    fun updateProduct(product: Product) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateProduct(product)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteProduct(product)
        }
    }

    fun clearLeads() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearLeads()
        }
    }

    // Order Actions
    fun updateOrderStatus(orderId: Long, status: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateOrderStatus(orderId, status)
        }
    }

    fun deleteOrder(order: CustomerOrder) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteOrder(order)
        }
    }

    fun clearOrders() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearOrders()
        }
    }

    fun addManualOrder(
        customerName: String,
        phone: String,
        address: String,
        productName: String,
        productCode: String,
        price: Double,
        paymentMethod: String,
        trxId: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val order = CustomerOrder(
                orderId = "#ORD-${(1000..9999).random()}",
                customerName = customerName,
                customerPhone = phone,
                deliveryAddress = address,
                productCode = productCode,
                productName = productName,
                totalPrice = price,
                paymentMethod = paymentMethod,
                trxId = trxId,
                status = CustomerOrder.STATUS_PENDING,
                platform = "Manual"
            )
            repository.insertOrder(order)
        }
    }

    fun addBkashTransaction(trxId: String, senderPhone: String, amount: Double, method: String = "bKash") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertBkashTransaction(
                BkashTransaction(
                    trxId = trxId.trim().uppercase(),
                    senderPhone = senderPhone,
                    amount = amount,
                    paymentMethod = method,
                    isClaimed = false
                )
            )
        }
    }

    fun simulateMessage(sender: String, platform: String, text: String) {
        viewModelScope.launch {
            _isSimulating.value = true
            val reply = withContext(Dispatchers.IO) {
                repository.processIncomingMessage(sender, platform, text)
            }
            _testSimulationReply.value = reply
            _isSimulating.value = false
        }
    }

    fun clearSimulationResult() {
        _testSimulationReply.value = null
    }

    fun savePaymentSettings(
        isBkash: Boolean,
        bkashNum: String,
        isNagad: Boolean,
        nagadNum: String,
        isRocket: Boolean,
        rocketNum: String
    ) {
        _settings.update {
            it.copy(
                isBkashEnabled = isBkash,
                bkashNumber = bkashNum,
                isNagadEnabled = isNagad,
                nagadNumber = nagadNum,
                isRocketEnabled = isRocket,
                rocketNumber = rocketNum
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            repository.isBkashEnabled = isBkash
            repository.bkashNumber = bkashNum
            repository.isNagadEnabled = isNagad
            repository.nagadNumber = nagadNum
            repository.isRocketEnabled = isRocket
            repository.rocketNumber = rocketNum
        }
    }

    private fun checkNotificationAccessGranted(context: Context): Boolean {
        val pkgName = context.packageName
        val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(pkgName)
    }
}
