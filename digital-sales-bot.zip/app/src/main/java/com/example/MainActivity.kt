package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.SalesBotViewModel
import com.example.ui.screens.*
import com.example.ui.theme.SalesBotTheme

enum class ScreenRoute(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    Dashboard("dashboard", "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    Orders("orders", "Orders", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong),
    Rules("rules", "Rules", Icons.Filled.Rule, Icons.Outlined.Rule),
    Products("products", "Products", Icons.Filled.ShoppingBag, Icons.Outlined.ShoppingBag),
    Leads("leads", "Messages", Icons.Filled.Forum, Icons.Outlined.Forum),
    Settings("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: SalesBotViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SalesBotTheme {
                val state by viewModel.uiState.collectAsStateWithLifecycle()
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route ?: ScreenRoute.Dashboard.route
                var showTestDialog by remember { mutableStateOf(false) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Text(
                                    text = ScreenRoute.values().find { it.route == currentRoute }?.title ?: "Digital Sales Bot",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        )
                    },
                    bottomBar = {
                        NavigationBar {
                            ScreenRoute.values().forEach { screen ->
                                val selected = currentRoute == screen.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.startDestinationId) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                            contentDescription = screen.title
                                        )
                                    },
                                    label = { Text(screen.title) }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = ScreenRoute.Dashboard.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(ScreenRoute.Dashboard.route) {
                            DashboardScreen(
                                state = state,
                                onToggleBot = viewModel::toggleBotActive,
                                onOpenTestBot = { showTestDialog = true },
                                onNavigateToOrders = { navController.navigate(ScreenRoute.Orders.route) },
                                onNavigateToRules = { navController.navigate(ScreenRoute.Rules.route) },
                                onNavigateToProducts = { navController.navigate(ScreenRoute.Products.route) },
                                onNavigateToLeads = { navController.navigate(ScreenRoute.Leads.route) }
                            )
                        }

                        composable(ScreenRoute.Orders.route) {
                            OrdersScreen(
                                state = state,
                                onUpdateOrderStatus = viewModel::updateOrderStatus,
                                onDeleteOrder = viewModel::deleteOrder,
                                onAddManualOrder = viewModel::addManualOrder,
                                onAddBkashTx = viewModel::addBkashTransaction
                            )
                        }

                        composable(ScreenRoute.Rules.route) {
                            RulesScreen(
                                state = state,
                                onAddRule = viewModel::addRule,
                                onToggleRule = viewModel::toggleRuleStatus,
                                onDeleteRule = viewModel::deleteRule,
                                onSaveAutoFollowupSettings = viewModel::saveAutoFollowupSettings
                            )
                        }

                        composable(ScreenRoute.Products.route) {
                            ProductsScreen(
                                state = state,
                                onAddProduct = viewModel::addProduct,
                                onUpdateProduct = viewModel::updateProduct,
                                onDeleteProduct = viewModel::deleteProduct
                            )
                        }

                        composable(ScreenRoute.Leads.route) {
                            LeadsScreen(
                                state = state,
                                onClearLeads = viewModel::clearLeads
                            )
                        }

                        composable(ScreenRoute.Settings.route) {
                            SettingsScreen(
                                state = state,
                                onToggleAi = viewModel::toggleAiEnabled,
                                onSetReplyDelay = viewModel::setReplyDelay,
                                onSaveAiConfig = viewModel::saveAiProviderConfig,
                                onTogglePlatform = viewModel::togglePlatform,
                                onSavePaymentSettings = viewModel::savePaymentSettings,
                                onSaveAutoFollowupSettings = viewModel::saveAutoFollowupSettings
                            )
                        }
                    }

                    if (showTestDialog) {
                        TestBotDialog(
                            isSimulating = state.isSimulating,
                            testReply = state.testSimulationReply,
                            onDismiss = {
                                viewModel.clearSimulationResult()
                                showTestDialog = false
                            },
                            onSimulate = viewModel::simulateMessage
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshPermissionStatus()
    }
}
