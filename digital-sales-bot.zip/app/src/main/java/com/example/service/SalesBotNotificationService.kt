package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.data.repository.SalesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SalesBotNotificationService : NotificationListenerService() {

    private lateinit var repository: SalesRepository
    private val serviceScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        repository = SalesRepository(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        if (!repository.isBotActive) return

        val packageName = sbn.packageName ?: return

        // Filter targeted messaging apps
        val platform = detectPlatform(packageName) ?: return
        if (!isPlatformAllowed(platform)) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Customer"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        if (text.isBlank()) return

        // Prevent self-reply or group system noise if text indicates bot response
        if (title.contains("Digital Sales Bot", ignoreCase = true) || title.contains("You", ignoreCase = true)) {
            return
        }

        // Find reply action with RemoteInput
        val replyAction = findReplyAction(sbn.notification)

        serviceScope.launch {
            val delayMs = (repository.replyDelaySeconds * 1000L).coerceAtLeast(500L)
            delay(delayMs)

            val botReply = repository.processIncomingMessage(
                senderName = title,
                platform = platform,
                messageText = text
            )

            if (replyAction != null) {
                sendDirectReply(replyAction, botReply)
            }
        }
    }

    private fun detectPlatform(pkg: String): String? {
        return when {
            pkg.contains("whatsapp") -> "WhatsApp"
            pkg.contains("facebook.orca") || pkg.contains("facebook.mlite") -> "Messenger"
            pkg.contains("telegram") -> "Telegram"
            pkg.contains("securesms") -> "Signal"
            pkg.contains("messaging") || pkg.contains("sms") || pkg.contains("mms") -> "SMS"
            else -> null
        }
    }

    private fun isPlatformAllowed(platform: String): Boolean {
        return when (platform) {
            "WhatsApp" -> repository.whatsappEnabled
            "Messenger" -> repository.messengerEnabled
            "Telegram" -> repository.telegramEnabled
            "SMS" -> repository.smsEnabled
            else -> true
        }
    }

    private fun findReplyAction(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        for (action in actions) {
            val remoteInputs = action.remoteInputs ?: continue
            for (remoteInput in remoteInputs) {
                if (remoteInput.allowFreeFormInput) {
                    return action
                }
            }
        }
        return null
    }

    private fun sendDirectReply(action: Notification.Action, replyText: String) {
        try {
            val intent = Intent()
            val bundle = Bundle()
            val remoteInputs = action.remoteInputs ?: return
            for (remoteInput in remoteInputs) {
                bundle.putCharSequence(remoteInput.resultKey, replyText)
            }
            RemoteInput.addResultsToIntent(remoteInputs, intent, bundle)
            action.actionIntent.send(applicationContext, 0, intent)
            Log.d("SalesBotService", "Direct reply sent successfully to notification")
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error sending direct notification reply", e)
        }
    }
}
