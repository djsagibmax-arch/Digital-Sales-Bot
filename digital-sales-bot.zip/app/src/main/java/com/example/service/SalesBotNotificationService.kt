package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.repository.SalesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SalesBotNotificationService : NotificationListenerService() {

    private lateinit var repository: SalesRepository
    private val serviceScope = CoroutineScope(Dispatchers.IO)
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        private const val CHANNEL_ID = "SalesBotServiceChannel"
        private const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        repository = SalesRepository(applicationContext)

        // Create Notification Channel for Foreground Service
        createNotificationChannel()

        // Acquire WakeLock so CPU stays awake when screen is off/locked
        acquireWakeLock()

        // Start Foreground Service with persistent status notification
        startForegroundServiceNotification()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseWakeLock()
    }

    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = powerManager?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "SalesBot:NotificationServiceWakeLock"
            )
            wakeLock?.acquire()
            Log.d("SalesBotService", "WakeLock acquired for background screen-off mode")
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error acquiring WakeLock", e)
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error releasing WakeLock", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Digital Sales Bot 24/7 Background Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "বট ব্যাকগ্রাউন্ডে এবং স্ক্রিন অফ থাকলেও স্বয়ংক্রিয়ভাবে রিপ্লাই দিতে সক্রিয় রয়েছে।"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundServiceNotification() {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🤖 ডিজিটাল সেলস বট ২৪/৭ সক্রিয়")
            .setContentText("স্ক্রিন অফ ও ব্যাকগ্রাউন্ডে মেসেজের উত্তর দেয়া চালু আছে")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        if (!repository.isBotActive) return

        val packageName = sbn.packageName ?: return

        // Filter targeted messaging apps
        val platform = detectPlatform(packageName) ?: return
        if (!isPlatformAllowed(platform)) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Customer"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        if (text.isBlank()) return

        // Prevent self-reply or system noise
        if (title.contains("Digital Sales Bot", ignoreCase = true) || title.contains("You", ignoreCase = true)) {
            return
        }

        // Find reply action with RemoteInput and Mark as Read action
        val replyAction = findReplyAction(sbn.notification)
        val markAsReadAction = findMarkAsReadAction(sbn.notification)

        serviceScope.launch {
            val delayMs = (repository.replyDelaySeconds * 1000L).coerceAtLeast(500L)
            delay(delayMs)

            val botReply = repository.processIncomingMessage(
                senderName = title,
                platform = platform,
                messageText = text
            )

            if (replyAction != null) {
                // Step 1 & 2: Check & fire 'Mark as Read' action if present to sync thread state on Messenger server
                if (markAsReadAction != null) {
                    Log.d("SalesBotService", "Found 'Mark as Read' action. Firing it first to mark message as seen/read...")
                    fireMarkAsReadAction(markAsReadAction)
                    // Step 3: Wait 1.5 seconds delay for server thread synchronization
                    delay(1500L)
                }

                // Step 4: Fire the Reply action to send the auto-reply message
                var primaryReplySent = false
                if (botReply.isNotBlank()) {
                    primaryReplySent = sendDirectReply(replyAction, botReply)
                    if (!primaryReplySent) {
                        Log.w("SalesBotService", "Direct notification reply failed to send.")
                    }
                }

                // Step 5: Auto Instant Follow-up / Default Message
                val isFollowupActive = repository.isAutoFollowupEnabled
                val followupText = repository.autoFollowupMessage.trim()
                val triggerMode = repository.autoFollowupTrigger

                if (isFollowupActive && followupText.isNotBlank()) {
                    val shouldSendFollowup = when (triggerMode) {
                        "CUSTOMER" -> true
                        "ROBOT" -> primaryReplySent || botReply.isNotBlank()
                        "BOTH" -> true
                        else -> true
                    }

                    if (shouldSendFollowup) {
                        Log.d("SalesBotService", "Triggering Auto Followup Message in 1.5s delay...")
                        delay(1500L)
                        sendDirectReply(replyAction, followupText)
                    }
                }
            } else {
                Log.w("SalesBotService", "No direct reply action found on notification shutter for package: ${sbn.packageName}")
            }
        }
    }

    private fun findMarkAsReadAction(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        for (action in actions) {
            // Exclude reply actions with freeform remote inputs
            val isReplyAction = action.remoteInputs?.any { it.allowFreeFormInput } == true
            if (isReplyAction) continue

            val title = action.title?.toString()?.lowercase() ?: ""
            if (title.contains("read") || 
                title.contains("পড়া") || 
                title.contains("পড়েছি") || 
                title.contains("seen") || 
                title.contains("দেখা") ||
                (title.contains("mark") && !title.contains("spam"))
            ) {
                return action
            }
        }
        return null
    }

    private fun fireMarkAsReadAction(action: Notification.Action): Boolean {
        return try {
            action.actionIntent.send()
            Log.d("SalesBotService", "Mark as Read PendingIntent executed successfully")
            true
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error executing Mark as Read PendingIntent", e)
            false
        }
    }

    private fun detectPlatform(pkg: String): String? {
        return when {
            pkg.contains("whatsapp") -> "WhatsApp"
            pkg.contains("facebook.orca") || pkg.contains("facebook.mlite") -> "Messenger"
            pkg.contains("telegram") -> "Telegram"
            pkg.contains("securesms") -> "Signal"
            pkg.contains("messaging") || pkg.contains("sms") || pkg.contains("mms") -> "SMS"
            else -> null
        }
    }

    private fun isPlatformAllowed(platform: String): Boolean {
        return when (platform) {
            "WhatsApp" -> repository.whatsappEnabled
            "Messenger" -> repository.messengerEnabled
            "Telegram" -> repository.telegramEnabled
            "SMS" -> repository.smsEnabled
            else -> true
        }
    }

    private fun findReplyAction(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        for (action in actions) {
            val remoteInputs = action.remoteInputs ?: continue
            for (remoteInput in remoteInputs) {
                if (remoteInput.allowFreeFormInput) {
                    return action
                }
            }
        }
        return null
    }

    private fun sendDirectReply(action: Notification.Action, replyText: String): Boolean {
        return try {
            val intent = Intent()
            val bundle = Bundle()
            val remoteInputs = action.remoteInputs ?: return false
            for (remoteInput in remoteInputs) {
                bundle.putCharSequence(remoteInput.resultKey, replyText)
            }
            RemoteInput.addResultsToIntent(remoteInputs, intent, bundle)
            action.actionIntent.send(applicationContext, 0, intent)
            Log.d("SalesBotService", "Direct reply sent successfully to notification shutter")
            true
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error sending direct notification reply", e)
            false
        }
    }
}
