package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.repository.SalesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SalesBotNotificationService : NotificationListenerService() {

    private lateinit var repository: SalesRepository
    private val serviceScope = CoroutineScope(Dispatchers.IO)
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        private const val CHANNEL_ID = "SalesBotServiceChannel"
        private const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        repository = SalesRepository(applicationContext)

        // Create Notification Channel for Foreground Service
        createNotificationChannel()

        // Acquire WakeLock so CPU stays awake when screen is off/locked
        acquireWakeLock()

        // Start Foreground Service with persistent status notification
        startForegroundServiceNotification()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseWakeLock()
    }

    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = powerManager?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "SalesBot:NotificationServiceWakeLock"
            )
            wakeLock?.acquire()
            Log.d("SalesBotService", "WakeLock acquired for background screen-off mode")
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error acquiring WakeLock", e)
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error releasing WakeLock", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Digital Sales Bot 24/7 Background Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "বট ব্যাকগ্রাউন্ডে এবং স্ক্রিন অফ থাকলেও স্বয়ংক্রিয়ভাবে রিপ্লাই দিতে সক্রিয় রয়েছে।"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundServiceNotification() {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🤖 ডিজিটাল সেলস বট ২৪/৭ সক্রিয়")
            .setContentText("স্ক্রিন অফ ও ব্যাকগ্রাউন্ডে মেসেজের উত্তর দেয়া চালু আছে")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        if (!repository.isBotActive) return

        val packageName = sbn.packageName ?: return

        // Filter targeted messaging apps
        val platform = detectPlatform(packageName) ?: return
        if (!isPlatformAllowed(platform)) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Customer"
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        if (text.isBlank()) return

        // Prevent self-reply or system noise
        if (title.contains("Digital Sales Bot", ignoreCase = true) || title.contains("You", ignoreCase = true)) {
            return
        }

        // Find reply action with RemoteInput
        val replyAction = findReplyAction(sbn.notification)

        serviceScope.launch {
            val delayMs = (repository.replyDelaySeconds * 1000L).coerceAtLeast(500L)
            delay(delayMs)

            val botReply = repository.processIncomingMessage(
                senderName = title,
                platform = platform,
                messageText = text
            )

            if (replyAction != null) {
                val sentSuccess = sendDirectReply(replyAction, botReply)
                if (!sentSuccess) {
                    Log.w("SalesBotService", "Direct reply failed. Attempting Messenger/Intent fallback.")
                    triggerMessengerOrPendingIntentFallback(sbn)
                }
            } else {
                Log.w("SalesBotService", "No direct reply action found on notification shutter. Triggering Messenger/Intent fallback.")
                triggerMessengerOrPendingIntentFallback(sbn)
            }
        }
    }

    private fun detectPlatform(pkg: String): String? {
        return when {
            pkg.contains("whatsapp") -> "WhatsApp"
            pkg.contains("facebook.orca") || pkg.contains("facebook.mlite") -> "Messenger"
            pkg.contains("telegram") -> "Telegram"
            pkg.contains("securesms") -> "Signal"
            pkg.contains("messaging") || pkg.contains("sms") || pkg.contains("mms") -> "SMS"
            else -> null
        }
    }

    private fun isPlatformAllowed(platform: String): Boolean {
        return when (platform) {
            "WhatsApp" -> repository.whatsappEnabled
            "Messenger" -> repository.messengerEnabled
            "Telegram" -> repository.telegramEnabled
            "SMS" -> repository.smsEnabled
            else -> true
        }
    }

    private fun findReplyAction(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        for (action in actions) {
            val remoteInputs = action.remoteInputs ?: continue
            for (remoteInput in remoteInputs) {
                if (remoteInput.allowFreeFormInput) {
                    return action
                }
            }
        }
        return null
    }

    private fun sendDirectReply(action: Notification.Action, replyText: String): Boolean {
        return try {
            val intent = Intent()
            val bundle = Bundle()
            val remoteInputs = action.remoteInputs ?: return false
            for (remoteInput in remoteInputs) {
                bundle.putCharSequence(remoteInput.resultKey, replyText)
            }
            RemoteInput.addResultsToIntent(remoteInputs, intent, bundle)
            action.actionIntent.send(applicationContext, 0, intent)
            Log.d("SalesBotService", "Direct reply sent successfully to notification shutter")
            true
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error sending direct notification reply", e)
            false
        }
    }

    private fun triggerMessengerOrPendingIntentFallback(sbn: StatusBarNotification) {
        try {
            // First try firing the notification's own pending content intent
            val contentIntent = sbn.notification.contentIntent
            if (contentIntent != null) {
                contentIntent.send()
                Log.d("SalesBotService", "Executed notification contentIntent fallback")
                return
            }

            // Fallback: Launch Facebook Messenger app
            val pm = packageManager
            val launchIntent = pm.getLaunchIntentForPackage("com.facebook.orca")
                ?: pm.getLaunchIntentForPackage("com.facebook.mlite")

            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                startActivity(launchIntent)
                Log.d("SalesBotService", "Launched Messenger app for first customer ID")
            }
        } catch (e: Exception) {
            Log.e("SalesBotService", "Error triggering Messenger/Intent fallback", e)
        }
    }
}
